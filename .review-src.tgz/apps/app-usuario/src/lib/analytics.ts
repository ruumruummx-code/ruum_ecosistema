"use client";

type ValorAnalitica = string | number | boolean | null | undefined;
type PropiedadesAnalitica = Record<string, ValorAnalitica>;

declare global {
  interface Window {
    dataLayer?: Array<Record<string, ValorAnalitica>>;
  }
}

export type EventoUxUsuario =
  | "login_visto"
  | "login_enviado"
  | "login_exitoso"
  | "login_error"
  | "registro_visto"
  | "registro_paso_visto"
  | "registro_enviado"
  | "registro_exitoso"
  | "registro_error"
  | "registro_confirmacion_vista"
  | "registro_confirmacion_url_deprecada"
  | "registro_confirmacion_enviada"
  | "registro_confirmacion_exitosa"
  | "registro_confirmacion_error"
  | "onboarding_visto"
  | "onboarding_completado"
  | "recuperacion_vista"
  | "recuperacion_enviada"
  | "recuperacion_exitosa"
  | "recuperacion_error"
  | "traslado_nuevo_visto"
  | "traslado_nuevo_sin_sesion"
  | "traslado_nuevo_enviado"
  | "traslado_nuevo_exitoso"
  | "traslado_nuevo_error"
  | "tarifa_gate_vista"
  | "tarifa_gate_calculada"
  | "tarifa_gate_no_disponible"
  | "tarifa_gate_aceptada"
  | "tarifa_gate_abandonada"
  | "soporte_enviado"
  | "soporte_visto"
  // 3.1 Eventos mejorados Fase 3
  | "traslado_paso_iniciado"
  | "traslado_paso_completado"
  | "tarifa_validacion_fallida"
  | "traslado_abandono"
  | "traslado_geocodificacion_error"
  | "traslado_rate_limit_hit"
  | "traslado_validacion_fallida";

export interface EventoTraslado {
  nombre: string;
  propiedades: {
    paso?: number;
    duracion_ms?: number;
    duracion_total_ms?: number;
    monto?: number;
    tarifa_anterior?: number;
    tarifa_nueva?: number;
    error_code?: string;
    razon?: string;
    timestamp: string;
  };
}

export function telemetriaPermitida(): boolean {
  if (typeof window === "undefined") return false;
  try {
    if (window.localStorage.getItem("ruum:telemetria-desactivada") === "true") return false;
    const usoDatos = window.localStorage.getItem("ruum:pref:usoDatos");
    if (usoDatos === '"Desactivado"' || usoDatos === "Desactivado") return false;
    return true;
  } catch {
    return true;
  }
}

export function desactivarTelemetriaActiva() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem("ruum:telemetria-desactivada", "true");
    if (window.dataLayer) {
      window.dataLayer.length = 0;
    }
    window.dispatchEvent(new CustomEvent("ruum:telemetria-detenida"));
  } catch {
    // ignore
  }
}

export function registrarEventoUx(evento: EventoUxUsuario, propiedades: PropiedadesAnalitica = {}) {
  if (typeof window === "undefined") return;
  if (!telemetriaPermitida()) return;

  const base: PropiedadesAnalitica = {
    timestamp: new Date().toISOString(),
    ...propiedades,
  };

  const detalle = {
    evento,
    ...base,
  };

  window.dispatchEvent(new CustomEvent("ruum:ux", { detail: detalle }));
  window.dataLayer?.push({ event: `ruum_${evento}`, ...base });

  // 3.1 forward a Sentry breadcrumb (no-op si no hay DSN).
  // A3: antes leía window.Sentry, que no es un global del SDK (@sentry/nextjs
  // v10 no lo expone): siempre era no-op aunque Sentry estuviera inicializado.
  // Se usa el SDK directamente con import dinámico para no crecer el chunk inicial.
  if (!process.env.VITEST && process.env.NEXT_PUBLIC_SENTRY_DSN?.trim()) {
    try {
      void import("@sentry/nextjs")
        .then((Sentry) => Sentry.addBreadcrumb?.({ category: "ux", message: evento, data: base, level: "info" }))
        .catch(() => {});
    } catch {}
  }
}

// Helpers Fase 3 — tracking de duración por paso y abandono
const pasoInicioMs = new Map<number, number>();
let flujoInicioMs: number | null = null;

export function iniciarFlujoTraslado() {
  flujoInicioMs = Date.now();
  pasoInicioMs.clear();
}

export function registrarPasoIniciado(paso: number) {
  pasoInicioMs.set(paso, Date.now());
  if (flujoInicioMs === null) flujoInicioMs = Date.now();
  registrarEventoUx("traslado_paso_iniciado", { paso, timestamp: new Date().toISOString() });
}

export function registrarPasoCompletado(paso: number) {
  const inicio = pasoInicioMs.get(paso);
  const duracion_ms = inicio ? Date.now() - inicio : undefined;
  registrarEventoUx("traslado_paso_completado", { paso, duracion_ms, timestamp: new Date().toISOString() });
}

export function registrarAbandono(paso: number, razon: string) {
  const duracion_total_ms = flujoInicioMs ? Date.now() - flujoInicioMs : undefined;
  registrarEventoUx("traslado_abandono", { paso, duracion_total_ms, razon, timestamp: new Date().toISOString() });
}
