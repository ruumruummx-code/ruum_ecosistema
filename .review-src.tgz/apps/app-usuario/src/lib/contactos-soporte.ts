import { crearConfiguracionContactosSoporte } from "@ruum/shared/constants";

export const CONTACTOS_SOPORTE_USUARIO = crearConfiguracionContactosSoporte({
  ambiente: process.env.NEXT_PUBLIC_RUUM_AMBIENTE ?? process.env.VERCEL_ENV ?? process.env.NEXT_PUBLIC_VERCEL_ENV,
  telefonoSoporte: process.env.NEXT_PUBLIC_RUUM_SOPORTE_TELEFONO,
  correoSoporte: process.env.NEXT_PUBLIC_RUUM_SOPORTE_CORREO,
  telefonoEmergencia: process.env.NEXT_PUBLIC_RUUM_EMERGENCIA_TELEFONO,
});
