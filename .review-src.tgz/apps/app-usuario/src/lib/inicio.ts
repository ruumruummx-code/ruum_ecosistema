import type { Database } from "@ruum/shared/types";
import { MENSAJES_CLAVE_UX } from "@ruum/shared/constants";
import { HORAS_HABILES_VERIFICACION_CUENTA_NUEVA } from "@ruum/shared/rules";

type PasaporteRow = Database["public"]["Views"]["pasaporte_digital"]["Row"];
type UsuarioRow = Database["public"]["Tables"]["usuarios"]["Row"];
type EstadoTraslado = Database["public"]["Enums"]["estado_traslado"];

/**
 * Estados en los que un traslado ya no necesita seguimiento en el Inicio.
 * El PRD no define un concepto de "viaje activo" para esta pantalla — es la
 * misma clase de decisión de UX que ya toma `packages/ui/src/lib/etapas.ts`
 * (ESTADOS_RAMIFICADOS) o `services/viajes.ts` (listarTrasladosAceptados) en
 * sus propios contextos: un traslado deja de ser "lo que está pasando ahora"
 * cuando se cierra, se cancela, falla, o su disputa/reclamo posterior al
 * cierre ya se resolvió. `cierre_operativo_con_incidencia_abierta` también
 * cuenta como cerrado: la parte operativa (mover el vehículo) ya terminó —
 * lo que sigue es un proceso de reclamo, no algo que se siga en el stepper.
 */
const ESTADOS_TRASLADO_FINALIZADOS: EstadoTraslado[] = [
  "servicio_cerrado",
  "servicio_cancelado",
  "traslado_fallido",
  "reclamo_resuelto",
  "disputa_resuelta",
  "cierre_operativo_con_incidencia_abierta"
];

export function esTrasladoActivo(estado: EstadoTraslado): boolean {
  return !ESTADOS_TRASLADO_FINALIZADOS.includes(estado);
}

function fechaOrdenable(fecha: string | null): number {
  return fecha ? new Date(fecha).getTime() : 0;
}

/**
 * Prioriza un traslado en curso o con incidencia; después, el activo más reciente para el
 * Inicio, o null si no hay ninguno. No asume que `traslados` venga
 * ordenado — ordena por su cuenta para no depender del caller.
 */
export function obtenerViajeActivo(traslados: PasaporteRow[]): PasaporteRow | null {
  const activos = [...traslados]
    .filter((t) => t.estado && !t.cerrado_en && t.estado_operativo !== "closed" && esTrasladoActivo(t.estado))
    .sort((a, b) => fechaOrdenable(b.creado_en) - fechaOrdenable(a.creado_en));

  return activos.find(t => t.estado === "traslado_en_curso" || t.estado === "incidencia_reportada") ?? activos[0] ?? null;
}

/** Todos los traslados, más recientes primero — para "Últimos Traslados". */
export function obtenerHistorial(traslados: PasaporteRow[]): PasaporteRow[] {
  return [...traslados].sort((a, b) => fechaOrdenable(b.creado_en) - fechaOrdenable(a.creado_en));
}

/**
 * Porcentaje ilustrativo del avance según la etapa operativa (solo visual,
 * para barras de progreso en Inicio y Traslados). No representa GPS real.
 */
export function progresoPorEstadoTraslado(estado: string | null): number {
  switch (estado) {
    case "solicitud_creada":
    case "documentacion_pendiente":
    case "documentacion_en_revision":
    case "documentacion_validada":
    case "cotizacion_generada":
    case "cotizacion_aceptada":
    case "servicio_confirmado":
    case "pendiente_de_conductor":
    case "pago_pendiente":
      return 15;
    case "conductor_asignado":
    case "conductor_en_camino_al_origen":
    case "conductor_en_punto_de_recoleccion":
    case "verificacion_vehiculo_en_proceso":
    case "evidencia_inicial_en_proceso":
    case "evidencia_inicial_completada":
    case "vehiculo_recibido":
      return 40;
    case "traslado_en_curso":
    case "incidencia_reportada":
      return 65;
    case "llegada_a_destino":
    case "evidencia_final_en_proceso":
    case "evidencia_final_completada":
      return 85;
    case "entrega_confirmada":
    case "pago_completado":
    case "servicio_cerrado":
      return 100;
    default:
      return 25;
  }
}

export interface NotificacionInicio {
  id: string;
  tono: "info" | "atencion" | "danger";
  mensaje: string;
  href?: string;
}

function folioCorto(trasladoId: string): string {
  return trasladoId.slice(0, 8).toUpperCase();
}

/**
 * No existe una tabla de notificaciones en el esquema (ver supabase/migrations).
 * Todo lo que el usuario necesita saber "ahora" ya está representado en el
 * estado de sus traslados y en su propio registro de usuario — esta función
 * deriva avisos a partir de esos datos reales en vez de inventar una fuente
 * nueva. Los de mayor urgencia (tono "atencion"/"danger") van primero.
 */
export function construirNotificaciones(usuario: UsuarioRow | null, traslados: PasaporteRow[]): NotificacionInicio[] {
  const notificaciones: NotificacionInicio[] = [];

  if (usuario?.estado_verificacion === "rechazado") {
    notificaciones.push({
      id: "verificacion-rechazada",
      tono: "danger",
      mensaje: "No pudimos verificar tu cuenta. Contáctanos para revisar qué falta.",
      href: "/soporte"
    });
  } else if (usuario?.estado_verificacion === "pendiente" || usuario?.estado_verificacion === "en_revision") {
    notificaciones.push({
      id: "verificacion-en-curso",
      tono: "info",
      mensaje: `Tu cuenta está en proceso de verificación — puede tardar hasta ${HORAS_HABILES_VERIFICACION_CUENTA_NUEVA} horas hábiles.`
    });
  }

  for (const traslado of traslados) {
    if (!traslado.traslado_id) continue;

    const folio = folioCorto(traslado.traslado_id);
    const href = `/viajes/${traslado.traslado_id}`;

    if (traslado.tiene_incidencia_abierta) {
      notificaciones.push({
        id: `incidencia-${traslado.traslado_id}`,
        tono: "atencion",
        mensaje: `Tu traslado ${folio} tiene una incidencia abierta. Te mantenemos informado.`,
        href
      });
    }

    if (traslado.estado === "pago_pendiente") {
      notificaciones.push({
        id: `pago-${traslado.traslado_id}`,
        tono: "atencion",
        mensaje: `Tienes un pago pendiente en tu traslado ${folio}. Págalo desde aquí.`,
        href
      });
    }

    if (traslado.estado === "reclamo_abierto" || traslado.estado === "disputa_abierta") {
      notificaciones.push({
        id: `disputa-${traslado.traslado_id}`,
        tono: "atencion",
        mensaje: `${MENSAJES_CLAVE_UX.disputa} (traslado ${folio})`,
        href
      });
    }

    if (traslado.estado === "dano_no_reportado_en_revision") {
      notificaciones.push({
        id: `dano-${traslado.traslado_id}`,
        tono: "atencion",
        mensaje: `Se reportó un posible daño no documentado en tu traslado ${folio}. Está en revisión.`,
        href
      });
    }
  }

  const prioridad = { danger: 0, atencion: 1, info: 2 };
  return notificaciones.sort((a, b) => prioridad[a.tono] - prioridad[b.tono]);
}
