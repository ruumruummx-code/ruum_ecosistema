/**
 * Sprint 4 (2026-07-11) — mismo patrón que
 * app-conductor/src/lib/borrador-registro.ts (Fase 4 + auditoría H-3):
 * borrador NO sensible del wizard de traslados/nuevo, con vigencia de 24h,
 * para retomarlo si la app se cierra a medio llenar. Ninguna otra pantalla
 * de app-usuario tenía este patrón todavía — el wizard de traslado es el
 * único formulario largo (4 pasos, ~30 campos) sin persistencia.
 *
 * Fuente de verdad del número de pasos: src/app/viajes/nuevo/NuevoTrasladoForm.tsx → PASOS.length.
 * No importar PASOS aquí para evitar dependencia circular; duplicar PASO_MAXIMO = 4 (= PASOS.length - 1).
 *
 * Excluido a propósito, por lo mismo que excluye borrador-registro.ts:
 *  - Domicilio preciso (calle, número, lat/lng): son domicilio real de
 *    origen/destino, no deben vivir en el almacenamiento del dispositivo.
 *  - Teléfonos de contacto de entrega/recepción: casi siempre son de un
 *    TERCERO (no de quien usa la app), no de quien llena el formulario.
 *  - VIN y placas: identifican un vehículo real de forma única.
 *  - Instrucciones especiales: texto libre que en la práctica suele traer
 *    referencias de domicilio o códigos de acceso.
 *  - vehiculoSeleccionadoId: si se restaura, mejor que la persona vuelva a
 *    elegir de su lista (ya cargada por sesión) que arrastrar un id viejo.
 *
 * Campos retirados del wizard (tipoServicio, motivoServicio): el esquema se
 * mantiene en v2 a propósito. Los borradores v2 ya guardados pueden traer
 * esas claves; la lectura las ignora (no están en CAMPOS_TEXTO) en vez de
 * descartar el borrador, que es lo que pasaría si se subiera la versión.
 */

const CLAVE_ACTUAL = "ruumruum.traslados-nuevo.borrador.v2";
const VERSION_ESQUEMA = 2;
const VIGENCIA_MS = 24 * 60 * 60 * 1000;
const LONGITUD_MAXIMA_CAMPO = 180;
export const PASO_MAXIMO = 4; // = PASOS.length - 1

export function formatearTiempoRelativoBorrador(guardadoEn: string, ahora: number = Date.now()): string {
  const guardadoMs = new Date(guardadoEn).getTime();
  if (!Number.isFinite(guardadoMs)) return "recientemente";
  const difSegundos = Math.max(0, Math.floor((ahora - guardadoMs) / 1000));
  if (difSegundos < 60) return "hace unos segundos";
  const difMinutos = Math.floor(difSegundos / 60);
  if (difMinutos < 60) return `hace ${difMinutos} ${difMinutos === 1 ? "minuto" : "minutos"}`;
  const difHoras = Math.floor(difMinutos / 60);
  if (difHoras < 24) return `hace ${difHoras} ${difHoras === 1 ? "hora" : "horas"}`;
  const difDias = Math.floor(difHoras / 24);
  return `hace ${difDias} ${difDias === 1 ? "día" : "días"}`;
}


export function ofuscarNumero(val: number): number {
  return Math.round(val * 100) / 100;
}

export function ofuscarCoordenada(coord: [number, number]): [number, number] {
  return [ofuscarNumero(coord[0]), ofuscarNumero(coord[1])];
}

export interface BorradorTrasladoLocal {
  versionEsquema: 2;
  claveIdempotencia: string;
  guardadoEn: string;
  expiraEn: string;
  paso: number;
  tipo: string;
  transmision: string;
  marca: string;
  modelo: string;
  anio: string;
  color: string;
  condicion: string;
  estadoGeneral: string;
  tieneTarjeta: boolean;
  tieneVerificacion: boolean;
  tienePlacas: boolean;
  puedeCircular: boolean;
  origenCodigoPostal: string;
  origenEstado: string;
  origenCiudad: string;
  origenColonia: string;
  origenLatOfuscada?: number | null;
  origenLngOfuscada?: number | null;
  origenPoiGenerico?: string | null;
  destinoCodigoPostal: string;
  destinoEstado: string;
  destinoCiudad: string;
  destinoColonia: string;
  destinoLatOfuscada?: number | null;
  destinoLngOfuscada?: number | null;
  destinoPoiGenerico?: string | null;
  entregaNombre: string;
  entregaApellido: string;
  recepcionNombre: string;
  recepcionApellido: string;
  modalidadProgramacion: string;
  fechaHoraProgramada: string;
  tipoRuta: string;
  ventanaRecoleccion: string;
  ventanaEntrega: string;
}

const CAMPOS_TEXTO = [
  "tipo", "transmision", "marca", "modelo", "anio", "color", "condicion", "estadoGeneral",
  "origenCodigoPostal", "origenEstado", "origenCiudad", "origenColonia",
  "destinoCodigoPostal", "destinoEstado", "destinoCiudad", "destinoColonia",
  "entregaNombre", "entregaApellido", "recepcionNombre", "recepcionApellido",
  "modalidadProgramacion", "fechaHoraProgramada", "tipoRuta",
  "ventanaRecoleccion", "ventanaEntrega"
] as const;

const CAMPOS_BOOLEANOS = ["tieneTarjeta", "tieneVerificacion", "tienePlacas", "puedeCircular"] as const;

export function limpiarBorradorTrasladoLocal() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(CLAVE_ACTUAL);
  } catch {
    // localStorage no está disponible; no queda nada más que limpiar.
  }
}

export function leerBorradorTrasladoLocal(): BorradorTrasladoLocal | null {
  if (typeof window === "undefined") return null;
  try {
    const crudo = window.localStorage.getItem(CLAVE_ACTUAL);
    if (!crudo) return null;
    const valor = JSON.parse(crudo) as unknown;
    if (!valor || typeof valor !== "object") throw new Error("esquema inválido");
    const dato = valor as Record<string, unknown>;
    if (dato.versionEsquema !== VERSION_ESQUEMA || typeof dato.guardadoEn !== "string" || typeof dato.expiraEn !== "string") {
      throw new Error("versión inválida");
    }
    const expira = new Date(dato.expiraEn).getTime();
    const guardado = new Date(dato.guardadoEn).getTime();
    if (!Number.isFinite(expira) || !Number.isFinite(guardado) || expira <= Date.now() || expira - guardado > VIGENCIA_MS) {
      throw new Error("borrador vencido");
    }

    const borrador: BorradorTrasladoLocal = {
      versionEsquema: 2,
      claveIdempotencia: typeof dato.claveIdempotencia === "string" && /^[0-9a-f-]{36}$/i.test(dato.claveIdempotencia)
        ? dato.claveIdempotencia
        : crypto.randomUUID(),
      guardadoEn: dato.guardadoEn,
      expiraEn: dato.expiraEn,
      paso: typeof dato.paso === "number" && Number.isInteger(dato.paso) && dato.paso >= 0 && dato.paso <= PASO_MAXIMO ? dato.paso : 0,
      tipo: "", transmision: "", marca: "", modelo: "", anio: "", color: "", condicion: "", estadoGeneral: "",
      tieneTarjeta: false, tieneVerificacion: false, tienePlacas: false, puedeCircular: false,
      origenCodigoPostal: "", origenEstado: "", origenCiudad: "", origenColonia: "",
      destinoCodigoPostal: "", destinoEstado: "", destinoCiudad: "", destinoColonia: "",
      entregaNombre: "", entregaApellido: "", recepcionNombre: "", recepcionApellido: "",
      modalidadProgramacion: "", fechaHoraProgramada: "", tipoRuta: "",
      ventanaRecoleccion: "", ventanaEntrega: ""
    };

    for (const campo of CAMPOS_TEXTO) {
      const contenido = dato[campo];
      if (typeof contenido !== "string" || contenido.length > LONGITUD_MAXIMA_CAMPO) {
        throw new Error(`campo inválido: ${campo}`);
      }
      borrador[campo] = contenido;
    }
    for (const campo of CAMPOS_BOOLEANOS) {
      borrador[campo] = Boolean(dato[campo]);
    }

    if (typeof dato.origenLatOfuscada === "number" && Number.isFinite(dato.origenLatOfuscada)) {
      borrador.origenLatOfuscada = ofuscarNumero(dato.origenLatOfuscada);
    }
    if (typeof dato.origenLngOfuscada === "number" && Number.isFinite(dato.origenLngOfuscada)) {
      borrador.origenLngOfuscada = ofuscarNumero(dato.origenLngOfuscada);
    }
    if (typeof dato.origenPoiGenerico === "string" && dato.origenPoiGenerico.length <= LONGITUD_MAXIMA_CAMPO) {
      borrador.origenPoiGenerico = dato.origenPoiGenerico;
    }
    if (typeof dato.destinoLatOfuscada === "number" && Number.isFinite(dato.destinoLatOfuscada)) {
      borrador.destinoLatOfuscada = ofuscarNumero(dato.destinoLatOfuscada);
    }
    if (typeof dato.destinoLngOfuscada === "number" && Number.isFinite(dato.destinoLngOfuscada)) {
      borrador.destinoLngOfuscada = ofuscarNumero(dato.destinoLngOfuscada);
    }
    if (typeof dato.destinoPoiGenerico === "string" && dato.destinoPoiGenerico.length <= LONGITUD_MAXIMA_CAMPO) {
      borrador.destinoPoiGenerico = dato.destinoPoiGenerico;
    }

    const hayContenido = CAMPOS_TEXTO.some((campo) => borrador[campo].trim());
    return hayContenido ? borrador : null;
  } catch {
    limpiarBorradorTrasladoLocal();
    return null;
  }
}

export function guardarBorradorTrasladoLocal(
  datos: Omit<BorradorTrasladoLocal, "versionEsquema" | "guardadoEn" | "expiraEn">
) {
  if (typeof window === "undefined") return;
  const ahora = Date.now();
  const borrador: BorradorTrasladoLocal = {
    ...datos,
    versionEsquema: VERSION_ESQUEMA,
    guardadoEn: new Date(ahora).toISOString(),
    expiraEn: new Date(ahora + VIGENCIA_MS).toISOString()
  };
  try {
    window.localStorage.setItem(CLAVE_ACTUAL, JSON.stringify(borrador));
  } catch {
    // El wizard funciona sin persistencia local.
  }
}
