import { z } from "zod";
import { ANTICIPACION_MINIMA_HORAS } from "@ruum/shared/validacion";

export const MAX_FILAS_MASIVAS = 100;
export const esquemaFilaMasiva = z.object({
  origenCodigoPostal: z.string().regex(/^\d{5}$/, "CP de 5 dígitos requerido"),
  destinoCodigoPostal: z.string().regex(/^\d{5}$/, "CP de 5 dígitos requerido"),
  marca: z.string().trim().min(1, "Marca requerida").max(80),
  modelo: z.string().trim().min(1, "Modelo requerido").max(80),
  anio: z.string().refine(v => /^\d{4}$/.test(v) && +v >= 1980 && +v <= new Date().getFullYear() + 1, "Año fuera del rango permitido"),
  condicion: z.enum(["nueva", "seminueva", "rescate_mecanico"], { message: "Usa nueva, seminueva o rescate_mecanico" }),
  entregaNombre: z.string().trim().min(1, "Nombre requerido").max(100),
  entregaTelefono: z.string().regex(/^\d{10}$/, "Teléfono de 10 dígitos requerido"),
  recepcionNombre: z.string().trim().min(1, "Nombre requerido").max(100),
  recepcionTelefono: z.string().regex(/^\d{10}$/, "Teléfono de 10 dígitos requerido"),
}).catchall(z.string().max(2000));
export type FilaMasivaEntrada = z.infer<typeof esquemaFilaMasiva>;
export interface FilaValidada {
  errorCotizacion?: string;
  indice: number;
  datos: FilaMasivaEntrada;
  errores: Record<string, string>;
  estado: "correcto" | "error";
}
export function normalizarTransmisionMasiva(valor: string) {
  return valor.trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
export function validarFila(datos: Record<string, string>, indice: number): FilaValidada {
  if (datos.vehiculo_transmision) datos = { ...datos, vehiculo_transmision: normalizarTransmisionMasiva(datos.vehiculo_transmision) };
  // Las fechas sin zona de la plantilla se capturan en hora de Ciudad de México,
  // independientemente de la zona del navegador o del servidor.
  if (datos.modalidad_programacion === "programado" && datos.fecha_hora_programada) {
    const fecha = datos.fecha_hora_programada.trim();
    const sinZona = /^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?$/.test(fecha);
    datos = { ...datos, fecha_hora_programada: sinZona ? `${fecha}-06:00` : fecha };
  }
  const resultado = esquemaFilaMasiva.safeParse(datos);
  const errores: Record<string, string> = {};
  if (datos.vehiculo_transmision && !["manual", "automatica", "electrica"].includes(datos.vehiculo_transmision)) errores.vehiculo_transmision = "Selecciona manual, automática o eléctrica";
  if (!resultado.success) for (const issue of resultado.error.issues) errores[String(issue.path[0])] = issue.message;
  if (!datos.vehiculo_placas && !datos.vehiculo_vin) errores.vehiculo_placas = "Captura placas o VIN";
  for (const lado of ["origen", "destino"]) {
    for (const campo of ["calle", "numero", "colonia"]) {
      const key = `${lado}_${campo}`;
      if (!datos[key]?.trim()) errores[key] = "Campo requerido";
    }
  }
  if (datos.modalidad_programacion === "programado") {
    const fecha = datos.fecha_hora_programada ?? "";
    const instante = Date.parse(fecha);
    const formato = /^(\d{4})-(\d{2})-(\d{2})T(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/.exec(fecha);
    const calendario = formato ? new Date(Date.UTC(+formato[1]!, +formato[2]! - 1, +formato[3]!)) : null;
    const diaValido = formato && calendario &&
      calendario.getUTCFullYear() === Number(formato[1]) &&
      calendario.getUTCMonth() + 1 === Number(formato[2]) &&
      calendario.getUTCDate() === Number(formato[3]);
    if (!Number.isFinite(instante) || !diaValido) errores.fecha_hora_programada = "Fecha y hora válidas requeridas";
    else if (instante < Date.now() + ANTICIPACION_MINIMA_HORAS * 60 * 60 * 1000) errores.fecha_hora_programada = `Programa con al menos ${ANTICIPACION_MINIMA_HORAS} horas de anticipación.`;
  }
  if (datos.modalidad_programacion && !["programado", "lo_antes_posible"].includes(datos.modalidad_programacion)) errores.modalidad_programacion = "Selecciona programado o lo_antes_posible";
  if (datos.modalidad_programacion !== "programado" && datos.fecha_hora_programada) errores.fecha_hora_programada = "Borra la fecha para un traslado lo antes posible";
  if (datos.tipo_traslado && !["local", "foraneo"].includes(datos.tipo_traslado)) errores.tipo_traslado = "Selecciona local o foraneo";
  for (const ventana of ["recoleccion", "entrega"]) {
    const key = `ventana_${ventana}_horario`;
    if (datos[`ventana_${ventana}`] === "específica" && !/^([01]\d|2[0-3]):[0-5]\d-([01]\d|2[0-3]):[0-5]\d$/.test(datos[key] ?? "")) errores[key] = "Usa HH:MM-HH:MM (24 h)";
  }
  return { indice, datos: (resultado.success ? resultado.data : datos) as FilaMasivaEntrada, errores, estado: Object.keys(errores).length ? "error" : "correcto" };
}

const ALIAS: Record<string, string> = {
  vehiculo_marca: "marca", vehiculo_modelo: "modelo", vehiculo_anio: "anio",
  origen_codigo_postal: "origenCodigoPostal", destino_codigo_postal: "destinoCodigoPostal",
  contacto_entrega_nombre: "entregaNombre", contacto_entrega_telefono: "entregaTelefono",
  contacto_recepcion_nombre: "recepcionNombre", contacto_recepcion_telefono: "recepcionTelefono",
};
export function normalizarFilaPlantilla(original: Record<string, string>): Record<string, string> {
  const datos = { ...original };
  if (datos.vehiculo_transmision) datos.vehiculo_transmision = normalizarTransmisionMasiva(datos.vehiculo_transmision);
  for (const [origen, destino] of Object.entries(ALIAS)) datos[destino] = original[origen] ?? original[destino] ?? "";
  for (const campo of ["origenCodigoPostal", "destinoCodigoPostal"]) if (/^\d{1,5}$/.test(datos[campo] ?? "")) datos[campo] = datos[campo]!.padStart(5, "0");
  for (const campo of ["entregaTelefono", "recepcionTelefono"]) datos[campo] = (datos[campo] ?? "").replace(/^\+52/, "").replace(/[\s()-]/g, "");
  return datos;
}

/** Las fórmulas nunca se ejecutan. Solo se leen sus resultados guardados. */
export function valorCelda(valor: unknown): string {
  if (valor == null) return "";
  // Excel almacena una hora civil sin zona. ExcelJS representa esos campos
  // como UTC; conservar la hora capturada y asignarle la zona de la plantilla.
  if (valor instanceof Date) return valor.toISOString().replace(/Z$/, "-06:00");
  if (typeof valor === "object") {
    if ("formula" in valor || "sharedFormula" in valor) return "result" in valor ? valorCelda(valor.result) : "";
    if ("richText" in valor && Array.isArray(valor.richText)) return valor.richText.map(v => v.text).join("");
    return "";
  }
  return String(valor).trim();
}

/**
 * Parsea el buffer de un archivo Excel de la plantilla oficial de traslados masivos.
 * Lee únicamente la hoja 'Traslados' ignorando celdas que son fórmulas vacías.
 */
export async function parsearBufferPlantilla(buffer: ArrayBuffer): Promise<Record<string, string>[]> {
  const ExcelJSModule = await import("exceljs");
  const WorkbookCtor =
    ("Workbook" in ExcelJSModule && ExcelJSModule.Workbook) ||
    ("default" in ExcelJSModule && (ExcelJSModule.default as unknown as { Workbook?: typeof ExcelJSModule.Workbook })?.Workbook) ||
    (ExcelJSModule as unknown as { Workbook: typeof ExcelJSModule.Workbook }).Workbook;
  if (!WorkbookCtor) {
    throw new Error("No se pudo iniciar el lector de hojas de cálculo.");
  }
  const wb = new WorkbookCtor();
  await wb.xlsx.load(buffer);

  const ws = wb.getWorksheet("Traslados") ?? (wb.worksheets ? wb.worksheets.find(w => w.name?.toLowerCase() === "traslados") : undefined);
  if (!ws) throw new Error("El archivo no contiene la hoja 'Traslados' de la plantilla oficial.");

  const headerRow = ws.getRow(1);
  const headers: Record<number, string> = {};
  headerRow.eachCell((cell, col) => {
    const val = valorCelda(cell.value).toLowerCase();
    if (val) headers[col] = val;
  });

  const obligatorios = ["vehiculo_marca", "vehiculo_modelo", "origen_codigo_postal", "destino_codigo_postal"];
  if (!obligatorios.every(h => Object.values(headers).includes(h))) {
    throw new Error("Usa los encabezados de la plantilla oficial.");
  }

  const filasBruto: Record<string, string>[] = [];
  ws.eachRow((row, rowNum) => {
    if (rowNum === 1) return; // saltar encabezados
    const obj: Record<string, string> = {};
    let capturada = false;
    row.eachCell((cell, col) => {
      const key = headers[col];
      if (key) obj[key] = valorCelda(cell.value);
      if (key && obj[key] && cell.type !== 6) capturada = true;
    });
    if (capturada) filasBruto.push({ ...normalizarFilaPlantilla(obj), __fila_excel: String(rowNum) });
  });

  if (filasBruto.length === 0) {
    throw new Error("El archivo no contiene datos de traslados para cotizar.");
  }
  if (filasBruto.length > MAX_FILAS_MASIVAS) {
    throw new Error(`El límite es de ${MAX_FILAS_MASIVAS} traslados por lote.`);
  }

  return filasBruto;
}

/**
 * Parsea el archivo de carga masiva delegando el procesamiento pesado a un Web Worker
 * para no bloquear el hilo de la UI del navegador, con fallback en entornos sin Web Worker.
 */
export async function parsearArchivoPlantilla(archivo: File, signal?: AbortSignal): Promise<Record<string, string>[]> {
  if (!archivo.name.toLowerCase().endsWith(".xlsx") || archivo.size > 5 * 1024 * 1024) {
    throw new Error("Selecciona la plantilla oficial .xlsx de hasta 5 MB.");
  }

  const buffer = await archivo.arrayBuffer();
  if (signal?.aborted) throw new DOMException("Operación abortada", "AbortError");

  if (typeof window !== "undefined" && typeof Worker !== "undefined") {
    return new Promise<Record<string, string>[]>((resolve, reject) => {
      let worker: Worker | null = null;
      try {
        worker = new Worker(new URL("./carga-masiva.worker.ts", import.meta.url), { type: "module" });
      } catch {
        worker = null;
      }

      if (!worker) {
        parsearBufferPlantilla(buffer).then(resolve, reject);
        return;
      }

      const cleanup = () => {
        if (worker) {
          worker.terminate();
          worker = null;
        }
      };

      if (signal) {
        signal.addEventListener("abort", () => {
          cleanup();
          reject(new DOMException("Operación abortada", "AbortError"));
        }, { once: true });
      }

      worker.onmessage = (e: MessageEvent<{ ok: boolean; filas?: Record<string, string>[]; error?: string }>) => {
        cleanup();
        if (e.data.ok && e.data.filas) {
          resolve(e.data.filas);
        } else {
          reject(new Error(e.data.error ?? "Error al procesar el archivo en segundo plano."));
        }
      };

      worker.onerror = (e) => {
        cleanup();
        reject(new Error(e.message || "Error en el worker de parseo de archivo."));
      };

      worker.postMessage({ buffer }, [buffer]);
    });
  }

  return parsearBufferPlantilla(buffer);
}

/** Nombres visibles de los campos de la plantilla; se comparten con el reporte. */
export const ETIQUETAS_CAMPOS_MASIVOS: Record<string, string> = {
  marca: "Marca", modelo: "Modelo", anio: "Año", condicion: "Condición del vehículo",
  vehiculo_placas: "Placas o VIN", vehiculo_vin: "VIN",
  origenCodigoPostal: "Código postal de origen", destinoCodigoPostal: "Código postal de destino",
  entregaNombre: "Nombre del contacto de entrega", entregaTelefono: "Teléfono de entrega",
  recepcionNombre: "Nombre del contacto de recepción", recepcionTelefono: "Teléfono de recepción",
  origen_calle: "Calle de origen", origen_numero: "Número de origen", origen_colonia: "Colonia de origen",
  destino_calle: "Calle de destino", destino_numero: "Número de destino", destino_colonia: "Colonia de destino",
  modalidad_programacion: "Modalidad de programación", fecha_hora_programada: "Fecha y hora programada",
  tipo_traslado: "Tipo de traslado", ventana_recoleccion_horario: "Horario de recolección", ventana_entrega_horario: "Horario de entrega",
};
export function motivosFilaMasiva(fila: FilaValidada): string[] {
  const motivos = Object.entries(fila.errores ?? {}).map(([campo, mensaje]) => (ETIQUETAS_CAMPOS_MASIVOS[campo] ?? campo.replaceAll("_", " ")) + ": " + mensaje);
  if (fila.errorCotizacion) motivos.push("Ruta o cotización: " + fila.errorCotizacion);
  return motivos;
}
export function numeroFilaExcel(fila: FilaValidada): number {
  const numero = Number(fila.datos.__fila_excel);
  return Number.isInteger(numero) && numero >= 2 ? numero : fila.indice + 2;
}
