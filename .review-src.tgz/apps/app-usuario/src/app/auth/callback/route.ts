/**
 * /auth/callback — Intercepta los deep links de Supabase Auth en app-usuario.
 *
 * Supabase redirige aquí tras confirmar email (signup), recuperar contraseña
 * (recovery) o usar magic link. Intercambia el code/token_hash por sesión y
 * redirige al destino correcto. Si el cliente recibe fragmentos hash (#access_token=...),
 * el fallback HTML/JS procesa la sesión en el navegador y enruta a /nueva-password o /.
 */
import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { crearClienteServidor } from "@ruum/api/supabase";
import { COOKIE_RECOVERY_USUARIO, destinoSeguro, MAX_AGE_RECOVERY_S, RUTA_COOKIE_RECOVERY } from "@ruum/shared/utils";
import { logStructuredWarn } from "@/lib/logger";

type TipoOtpSanitizado = "signup" | "recovery" | "magiclink" | "email";

const COOKIE_RECOVERY = COOKIE_RECOVERY_USUARIO;

function opcionesCookieRecovery() {
  /* CORRECCIÓN (auditoría S-6): esta cookie ES la autorización para cambiar la
     contraseña. Con `secure: isProd` se emitía sin Secure en staging/preview,
    单位和 vía en claro por HTTP. Ahora solo se relaja en desarrollo local. */
  const secure = process.env.NODE_ENV !== "development";
  return {
    httpOnly: true as const,
    secure,
    sameSite: "lax" as const,
    maxAge: MAX_AGE_RECOVERY_S,
    path: RUTA_COOKIE_RECOVERY,
  };
}

async function setRecoveryCookie(
  cookieStore: Awaited<ReturnType<typeof cookies>>,
  supabase: ReturnType<typeof crearClienteServidor>,
  userDirecto?: { id?: string } | null
) {
  try {
    const userId = userDirecto?.id ?? (await supabase.auth.getUser()).data.user?.id;
    /* CORRECCIÓN: antes, si getUser() fallaba, se seteaba la cookie con "1" y
       /api/recovery/verify la aceptaba sin validar userId. Ahora solo se
       marca autorización cuando el usuario es conocido. */
    if (!userId) return;
    cookieStore.set(COOKIE_RECOVERY, userId, opcionesCookieRecovery());
  } catch (err) {
    // No se setea marcador: /nueva-password rechazará el acceso.
    logStructuredWarn("auth/callback", "set_recovery_cookie_fallido", err);
  }
}

function clearRecoveryCookie(cookieStore: Awaited<ReturnType<typeof cookies>>) {
  const opts = { path: RUTA_COOKIE_RECOVERY } as const;
  try {
    cookieStore.delete(COOKIE_RECOVERY);
    cookieStore.delete("ruum_recovery");
  } catch {
    // best-effort
  }
  // Next 15 cookies().delete necesita path; fallback set expirado
  try {
    cookieStore.set(COOKIE_RECOVERY, "", { ...opcionesCookieRecovery(), maxAge: 0 });
    cookieStore.set("ruum_recovery", "", { ...opcionesCookieRecovery(), maxAge: 0 });
  } catch {}
}

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const tokenHash =
    searchParams.get("token_hash") ||
    searchParams.get("token") ||
    searchParams.get("confirmation_token");
  const rawType = (searchParams.get("type") || searchParams.get("event") || "").toLowerCase();
  const nextParam = (searchParams.get("next") || searchParams.get("redirectTo") || "").toLowerCase();

  // Mapear tipos de Supabase a los valores reconocidos por verifyOtp/recovery
  let type: TipoOtpSanitizado = "signup";
  if (rawType === "recovery" || nextParam.includes("nueva-password")) {
    type = "recovery";
  } else if (rawType === "magiclink") {
    type = "magiclink";
  } else if (rawType === "email" || rawType === "email_change") {
    type = "email";
  } else {
    type = "signup";
  }

  /* CORRECCIÓN (auditoría S-1): el guard anterior `startsWith("/") && !startsWith("//")`
     dejaba pasar "/\evil.com". El parser WHATWG normaliza "\" a "/", así que el
     Location resultante cruzaba al dominio atacante tras un login exitoso. */
  const nextSolicitado = searchParams.get("next");
  const next = destinoSeguro(nextSolicitado, type === "recovery" ? "/nueva-password" : "/");

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;

  const destinoErrorServer =
    type === "recovery"
      ? "/recuperar-password?error=enlace_invalido"
      : "/login?reason=email_confirmation&error=enlace_invalido";

  // Si no hay configuración de Supabase, redirigir al fallback de error
  if (!url || !anonKey) {
    return NextResponse.redirect(`${origin}${destinoErrorServer}`);
  }

function clasificarCausaError(error: unknown, searchParams: URLSearchParams): "expirado" | "reutilizado" | "otro_dispositivo" {
  const errorObj = error as { message?: string; code?: string } | null;
  const errorMsg = (errorObj?.message || searchParams.get("error_description") || "").toLowerCase();
  const errorCode = (errorObj?.code || searchParams.get("error_code") || "").toLowerCase();

  if (errorCode.includes("otp_expired") || errorMsg.includes("expired") || errorMsg.includes("caduc") || errorMsg.includes("expirad")) {
    return "expirado";
  }
  if (errorMsg.includes("flow_state") || errorMsg.includes("code_verifier") || errorMsg.includes("pkce") || errorMsg.includes("different device")) {
    return "otro_dispositivo";
  }
  if (errorMsg.includes("already") || errorMsg.includes("reutiliz") || errorMsg.includes("used") || errorMsg.includes("consum")) {
    return "reutilizado";
  }
  return "expirado";
}

  const cookieStore = await cookies();
  const supabase = crearClienteServidor(url, anonKey, {
    getAll() {
      return cookieStore.getAll();
    },
    setAll(cookiesToSet) {
      try {
        cookiesToSet.forEach(({ name, value, options }) =>
          cookieStore.set(name, value, options)
        );
      } catch {
        /* Route Handler puede escribir cookies */
      }
    },
  });

  // Detectar cuenta abierta previamente para evitar cambio silencioso de sesión
  let usuarioPrevioEmail: string | null = null;
  let usuarioPrevioId: string | null = null;
  try {
    const { data: dataPrevia } = await supabase.auth.getUser();
    usuarioPrevioId = dataPrevia?.user?.id ?? null;
    usuarioPrevioEmail = dataPrevia?.user?.email ?? null;
  } catch {
    // Sin sesión previa activa
  }

  // 1. Flujo PKCE (autorización por código)
  if (code) {
    const { data: dataAuth, error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      let queryMismatch = "";
      if (type === "recovery") {
        // T5: Consolidación de getUser() - reusar dataAuth.user para evitar 2 round-trips extra a GoTrue
        const nuevoUser = dataAuth?.user ?? (await supabase.auth.getUser().then((r) => r.data?.user).catch(() => null));
        await setRecoveryCookie(cookieStore, supabase, nuevoUser);
        try {
          if (usuarioPrevioId && nuevoUser && nuevoUser.id !== usuarioPrevioId) {
            queryMismatch = `?cuenta_distinta=1&anterior=${encodeURIComponent(usuarioPrevioEmail || "")}&nueva=${encodeURIComponent(nuevoUser.email || "")}`;
          }
        } catch (err) {
          logStructuredWarn("auth/callback", "verificacion_cambio_cuenta_pkce_omitida", err);
        }
      } else {
        clearRecoveryCookie(cookieStore);
      }
      const destino = type === "recovery" ? `/nueva-password${queryMismatch}` : next;
      return NextResponse.redirect(`${origin}${destino}`);
    }
    // Código inválido/expirado/reutilizado -> limpiar marcador y redirigir a error con causa clasificada.
    if (type === "recovery") clearRecoveryCookie(cookieStore);
    const causa = clasificarCausaError(error, searchParams);
    const destinoError = type === "recovery"
      ? `/recuperar-password?error=enlace_invalido&causa=${causa}`
      : `/login?reason=email_confirmation&error=enlace_invalido&causa=${causa}`;
    return NextResponse.redirect(`${origin}${destinoError}`);
  }

  // 2. Flujo OTP / Hash (verificación de token por correo)
  if (tokenHash) {
    const { data: dataAuth, error } = await supabase.auth.verifyOtp({
      type,
      token_hash: tokenHash,
    });
    if (!error) {
      let queryMismatch = "";
      if (type === "recovery") {
        // T5: Consolidación de getUser() - reusar dataAuth.user
        const nuevoUser = dataAuth?.user ?? (await supabase.auth.getUser().then((r) => r.data?.user).catch(() => null));
        await setRecoveryCookie(cookieStore, supabase, nuevoUser);
        try {
          if (usuarioPrevioId && nuevoUser && nuevoUser.id !== usuarioPrevioId) {
            queryMismatch = `?cuenta_distinta=1&anterior=${encodeURIComponent(usuarioPrevioEmail || "")}&nueva=${encodeURIComponent(nuevoUser.email || "")}`;
          }
        } catch (err) {
          logStructuredWarn("auth/callback", "verificacion_cambio_cuenta_pkce_omitida", err);
        }
      } else {
        clearRecoveryCookie(cookieStore);
      }
      const destino = type === "recovery" ? `/nueva-password${queryMismatch}` : next;
      return NextResponse.redirect(`${origin}${destino}`);
    }
    if (type === "recovery") clearRecoveryCookie(cookieStore);
    const causa = clasificarCausaError(error, searchParams);
    const destinoError = type === "recovery"
      ? `/recuperar-password?error=enlace_invalido&causa=${causa}`
      : `/login?reason=email_confirmation&error=enlace_invalido&causa=${causa}`;
    return NextResponse.redirect(`${origin}${destinoError}`);
  }

  // 3. Respuesta HTML/JS ligera para capturar fragmentos de hash en el navegador (#access_token=... o fallback)
  /* CORRECCIÓN (auditoría A-2): el <script> sin nonce quedaba bloqueado en
     producción. Con 'strict-dynamic' + nonce, CSP3 ignora las fuentes de host
     (incluido 'self'), así que el fallback nunca se ejecutaba y el usuario
     quedaba en una pantalla estática infinita. El middleware ya inyecta
     `x-nonce` en la request (src/middleware.ts:62). */
  const nonce = request.headers.get("x-nonce") ?? "";
  const attrNonce = nonce ? ` nonce="${nonce.replace(/[^A-Za-z0-9+/=_-]/g, "")}"` : "";

  const htmlFallback = `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="utf-8">
      <title>Verificando cuenta...</title>
      <style>
        body { font-family: system-ui, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100dvh; margin: 0; background: #070d18; color: #f8faf5; }
        .card { text-align: center; padding: 2rem; border-radius: 1rem; background: #0d1526; border: 1px solid #1c2a3e; max-width: 400px; }
        a { color: #7fd4d0; }
      </style>
    </head>
    <body>
      <div class="card">
        <p>Verificando tu enlace de seguridad...</p>
        <noscript>
          <p>Necesitamos JavaScript para verificar tu enlace.</p>
          <p><a href="/login">Ir al inicio de sesión</a></p>
        </noscript>
      </div>
      <script src="/auth-callback-fallback.js"${attrNonce}></script>
    </body>
    </html>
  `;

  return new NextResponse(htmlFallback, {
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}
