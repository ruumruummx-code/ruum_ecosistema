"use client";

import { useState, useTransition } from "react";
import { Button } from "@ruum/ui";
import { MENSAJES_CLAVE_UX, TEXTOS_CARGANDO } from "@ruum/shared/constants";
import { crearCalificacion } from "@ruum/api/services";
import { crearClienteNavegador, tieneSupabaseConfigurado } from "@/lib/supabase-browser";

export function CalificarTraslado({
  trasladoId,
  conductorId,
  mostrar,
  onEnviada
}: {
  trasladoId: string;
  conductorId: string | null;
  mostrar: boolean;
  onEnviada?: () => void;
}) {
  const [estrellas, setEstrellas] = useState(5);
  const [comentario, setComentario] = useState("");
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [enviado, setEnviado] = useState(false);
  const [pendiente, startTransition] = useTransition();

  if (!mostrar || !conductorId) return null;

  if (enviado) {
    return (
      <div
        className="mt-6 rounded-lg border border-signal/20 bg-signal-soft/35 px-4 py-4"
        role="status"
        aria-live="polite"
        aria-atomic="true"
      >
        <p className="font-body text-sm font-semibold text-ink">
          Calificación registrada. Gracias por ayudarnos a mantener la calidad.
        </p>
      </div>
    );
  }

  function enviar() {
    setMensaje(null);
    startTransition(async () => {
      try {
        if (!tieneSupabaseConfigurado()) {
          setMensaje("Supabase no está configurado. No se puede registrar la calificación.");
          return;
        }
        const cliente = crearClienteNavegador();
        await crearCalificacion(cliente, trasladoId, conductorId!, estrellas, comentario);
        setEnviado(true);
        onEnviada?.();
        setMensaje("Calificación registrada. Gracias por ayudarnos a mantener la calidad.");
      } catch (error) {
        setMensaje(error instanceof Error ? error.message : "No se pudo registrar la calificación.");
      }
    });
  }

  return (
    <div className="mt-6 rounded-lg border border-signal/20 bg-signal-soft/35 px-4 py-4">
      <p className="font-body text-sm font-semibold" id="titulo-calificacion">{MENSAJES_CLAVE_UX.calificacion}</p>
      <div className="mt-3 flex gap-2" role="radiogroup" aria-labelledby="titulo-calificacion">
        {[1, 2, 3, 4, 5].map((valor) => (
          <button
            key={valor}
            type="button"
            role="radio"
            aria-checked={valor === estrellas}
            onClick={() => setEstrellas(valor)}
            className={`inline-flex min-h-11 min-w-11 items-center justify-center rounded-lg text-2xl leading-none transition focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-2 focus-visible:outline-route-dark ${valor <= estrellas ? "text-signal" : "text-ink/25"}`}
            aria-label={`${valor} estrella${valor === 1 ? "" : "s"}${valor === estrellas ? " (seleccionada)" : ""}`}
          >
            <span aria-hidden="true">★</span>
          </button>
        ))}
      </div>
      <label className="flex flex-col gap-1">
        <span className="sr-only">Comentario de calificación</span>
        <textarea
          value={comentario}
          onChange={(evento) => setComentario(evento.target.value)}
          className="mt-3 min-h-24 w-full rounded-lg border border-ink/50 bg-mist px-3 py-2 font-body text-sm focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-1 focus-visible:outline-route-dark"
          placeholder="Comentario opcional"
          maxLength={500}
          aria-label="Comentario de calificación"
        />
        <span className="text-right font-body text-xs text-ink/40">{comentario.length}/500</span>
      </label>
      <div className="mt-3 flex items-center gap-3">
        <Button onClick={enviar} disabled={pendiente}>
          {pendiente ? TEXTOS_CARGANDO.enviando : "Enviar calificación"}
        </Button>
        <div role="status" aria-live="polite" aria-atomic="true" className="min-h-[20px]">
        {mensaje && <span className="font-body text-sm text-ink/60">{mensaje}</span>}
      </div>
      </div>
    </div>
  );
}
