// Vitest ejecuta estas rutas de servidor fuera del compilador de Next.
vi.mock("server-only", () => ({}));
import { describe, expect, it, vi } from "vitest";
import { GET as getResend } from "./auth/resend/route";
import { GET as getSignup } from "./auth/signup/route";
import { GET as getVerifyOtp } from "./auth/verify-otp/route";
import { GET as getPhoneVerifySend } from "./auth/phone-verify/send/route";
import { GET as getPhoneVerifyVerify } from "./auth/phone-verify/verify/route";
import { GET as getViajes } from "./viajes/route";

/** Los 405 informan el método permitido (RFC 9110 §15.5.6). */
describe("405 — cabecera Allow", () => {
  it("resend/signup/verify-otp/viajes responden 405 + Allow: POST", async () => {
    for (const get of [
      getResend,
      getSignup,
      getVerifyOtp,
      getPhoneVerifySend,
      getPhoneVerifyVerify,
      getViajes,
    ]) {
      const res = await get();
      expect(res.status).toBe(405);
      expect(res.headers.get("Allow")).toBe("POST");
    }
  });
});
