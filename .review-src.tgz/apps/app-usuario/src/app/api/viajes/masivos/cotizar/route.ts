import { NextRequest, NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { validarFila } from "@/lib/carga-masiva";
import { z } from "zod";
import { crearClienteServidor } from "@/lib/supabase-server";
import { rateLimitMasivo } from "@/lib/rate-limit-masivos";
import { logStructuredError, logStructuredWarn } from "@/lib/logger";
import { registrarMetricaCotizacion } from "@/lib/carga-masiva-telemetria";
import { verificarCsrfORechazar } from "@/lib/csrf";
import { clienteMasivoServicio, stripeMasivo, validarFilasServidor } from "@/lib/carga-masiva-server";
import { previsualizarTarifasMasivasUsuario, verificarUsuarioMasivo, guardarCheckoutMasivoServidor, reservarCheckoutMasivoServidor, vincularPagoMasivoServidor, eliminarCheckoutMasivoServidor, obtenerClienteBilleteraServidor } from "@ruum/api/services";
import { coordenadaPostalMasiva, ErrorServicioCotizacion } from "@/lib/mapbox-masivo";
import { tipoSugeridoParaVehiculo } from "@ruum/shared/catalogos";
import { obtenerRutaDirectionsMapboxConParadas } from "@ruum/shared/utils";
export const dynamic = "force-dynamic";
export const maxDuration = 300;
const esquema = z.object({
  filas: z.array(z.record(z.string(), z.string().max(2000))).min(1).max(100),
  clave: z.string().uuid(),
  permitirParcial: z.boolean().optional(),
});
const LIMITE_CELDAS = 4000;
const LIMITE_BYTES_JSON = 5 * 1024 * 1024;
const LIMITE_CPU_MS = 240_000;

function hashRuta(filas: Record<string, string>[]): string {
  const entradas = filas.map((fila) => ({
    origen: [fila.origenCodigoPostal, fila.origen_calle, fila.origen_numero, fila.origen_colonia],
    destino: [fila.destinoCodigoPostal, fila.destino_calle, fila.destino_numero, fila.destino_colonia],
    marca: fila.marca, modelo: fila.modelo, anio: fila.anio, condicion: fila.condicion,
    modalidad: fila.modalidad_programacion, fecha: fila.fecha_hora_programada,
  }));
  return createHash("sha256").update(JSON.stringify(entradas)).digest("hex");
}

export async function POST(request: NextRequest) {
  const rechazoCsrf = verificarCsrfORechazar(request);
  if (rechazoCsrf) return rechazoCsrf;
  const cliente = await crearClienteServidor();
  const { data: { user } } = await cliente.auth.getUser();
  if (!user) return NextResponse.json({ error: "No autenticado" }, { status: 401 });
  const limite = await rateLimitMasivo(request, user.id, "masivos-cotizar", 5);
  if (!limite.allowed) return NextResponse.json({ error: "Espera antes de cotizar otra carga." }, { status: 429, headers: { "Retry-After": String(limite.retryAfterSec) } });
  const raw = await request.text().catch(() => "");
  if (new TextEncoder().encode(raw).length > LIMITE_BYTES_JSON) return NextResponse.json({ error: "La carga excede el límite de tamaño permitido." }, { status: 413 });
  let payload: unknown = null;
  try { payload = JSON.parse(raw || "null"); } catch { return NextResponse.json({ error: "La carga no es válida." }, { status: 400 }); }
  const body = esquema.safeParse(payload);
  if (!body.success) return NextResponse.json({ error: "La carga no es válida." }, { status: 400 });
  const totalCeldas = body.data.filas.reduce((total, fila) => total + Object.keys(fila).length, 0);
  if (totalCeldas > LIMITE_CELDAS) return NextResponse.json({ error: `La carga supera el máximo de ${LIMITE_CELDAS} celdas.` }, { status: 413 });
  const permitirParcial = Boolean(body.data.permitirParcial);
  const inicioCotizacion = performance.now();
  const assertBudget = () => {
    if (performance.now() - inicioCotizacion > LIMITE_CPU_MS) throw new Error("MASIVOS_CPU_BUDGET_EXCEEDED");
  };
  try {
    if (!await verificarUsuarioMasivo(cliente, user.id)) return NextResponse.json({ error: "Verifica tu cuenta antes de pagar." }, { status: 403 });
    const filas = await validarFilasServidor(body.data.filas);
    if (!permitirParcial && filas.some(f => f.estado === "error")) return NextResponse.json({ filas });
    const token = process.env.MAPBOX_SECRET_TOKEN;
    if (!token) return NextResponse.json({ error: "Servicio de mapas no configurado (falta MAPBOX_SECRET_TOKEN)." }, { status: 500 });
    const normalizadas: Record<string, string>[] = [];
    const cotizaciones = [];
    let centavos = 0;
    const momento = new Date().toISOString();
    type Ruta = { origen: [number, number]; destino: [number, number]; distanciaKm: number; tiempoHoras: number };
    const rutas = new Map<number, Ruta>();

    // 1. Geocodificación optimizada: geocodificar CPs únicos para evitar llamadas redundantes a Mapbox.
    const cpsUnicos = Array.from(new Set(
      filas.flatMap(f => [f.datos.origenCodigoPostal, f.datos.destinoCodigoPostal]).filter(Boolean)
    ));
    const coordenadasPorCP = new Map<string, [number, number] | null>();
    const TAMANIO_LOTE_CP = 10;
    for (let i = 0; i < cpsUnicos.length; i += TAMANIO_LOTE_CP) {
      assertBudget();
      const loteCP = cpsUnicos.slice(i, i + TAMANIO_LOTE_CP);
      await Promise.all(
        loteCP.map(async (cp) => {
          try {
            const coord = await coordenadaPostalMasiva(cp, token);
            coordenadasPorCP.set(cp, coord);
          } catch (err) {
            if (err instanceof ErrorServicioCotizacion && (err.status === 401 || err.status === 403)) {
              throw err;
            }
            coordenadasPorCP.set(cp, null);
          }
        })
      );
    }

    for (const fila of filas) {
      const d = fila.datos;
      const origen = coordenadasPorCP.get(d.origenCodigoPostal);
      const destino = coordenadasPorCP.get(d.destinoCodigoPostal);
      if (!origen || !destino) {
        if (!origen) fila.errores.origenCodigoPostal = "El servicio de mapas no encontró el CP de origen.";
        if (!destino) fila.errores.destinoCodigoPostal = "El servicio de mapas no encontró el CP de destino.";
        fila.estado = "error";
      }
    }
    if (!permitirParcial && filas.some(f => f.estado === "error")) return NextResponse.json({ filas });

    // 2. Cálculo de rutas optimizado: pares únicos (origenCP, destinoCP).
    // Si múltiples traslados tienen los mismos CPs de origen y destino, se calcula la ruta una sola vez.
    const paresUnicos = new Map<string, { origenCP: string; destinoCP: string; origen: [number, number]; destino: [number, number] }>();
    for (const fila of filas) {
      if (fila.estado === "error") continue;
      const origen = coordenadasPorCP.get(fila.datos.origenCodigoPostal);
      const destino = coordenadasPorCP.get(fila.datos.destinoCodigoPostal);
      if (!origen || !destino) continue;
      const clavePar = `${fila.datos.origenCodigoPostal}:${fila.datos.destinoCodigoPostal}`;
      if (!paresUnicos.has(clavePar)) {
        paresUnicos.set(clavePar, { origenCP: fila.datos.origenCodigoPostal, destinoCP: fila.datos.destinoCodigoPostal, origen, destino });
      }
    }

    const rutasPorPar = new Map<string, { distanciaKm: number; tiempoHoras: number }>();
    const erroresPorPar = new Map<string, string>();
    const paresLista = Array.from(paresUnicos.entries());
    const TAMANIO_LOTE_RUTAS = 10;
    for (let i = 0; i < paresLista.length; i += TAMANIO_LOTE_RUTAS) {
      assertBudget();
      const lotePares = paresLista.slice(i, i + TAMANIO_LOTE_RUTAS);
      await Promise.all(
        lotePares.map(async ([clavePar, par]) => {
          const MAX_INTENTOS = 2;
          let ultimoError: unknown = null;
          for (let intento = 0; intento <= MAX_INTENTOS; intento++) {
            try {
              if (intento > 0) {
                await new Promise((resolve) => setTimeout(resolve, 300 * intento));
              }
              const ruta = await obtenerRutaDirectionsMapboxConParadas(
                par.origen,
                par.destino,
                [],
                token,
                { lanzarErrores: true, maxIntentos: 2, timeoutMs: 8000, demoraReintentoMs: 300 }
              );
              if (!ruta || ruta.distanciaKm == null || ruta.tiempoHoras == null) {
                erroresPorPar.set(clavePar, "No existe una ruta compatible para este traslado.");
                return;
              }
              rutasPorPar.set(clavePar, { distanciaKm: ruta.distanciaKm, tiempoHoras: ruta.tiempoHoras });
              return;
            } catch (err) {
              ultimoError = err;
              if (err instanceof ErrorServicioCotizacion && (err.status === 401 || err.status === 403)) {
                throw err;
              }
              if (intento === MAX_INTENTOS) {
                logStructuredWarn("api/viajes/masivos/cotizar", "ruta_par_agotada", err, {
                  clavePar,
                  intentos: intento + 1,
                });
              }
            }
          }
          if (ultimoError instanceof ErrorServicioCotizacion && ultimoError.status === 429) {
            erroresPorPar.set(clavePar, "El servicio de mapas alcanzó su límite de consultas para esta fila. Reintenta esta fila.");
          } else {
            erroresPorPar.set(clavePar, "No se pudo calcular la ruta de este traslado (tiempo de espera o error de red). Reintenta o revisa sus ubicaciones.");
          }
        })
      );
    }

    for (const fila of filas) {
      assertBudget();
      if (fila.estado === "error") continue;
      const clavePar = `${fila.datos.origenCodigoPostal}:${fila.datos.destinoCodigoPostal}`;
      const ruta = rutasPorPar.get(clavePar);
      if (!ruta) {
        fila.errorCotizacion = erroresPorPar.get(clavePar) ?? "No existe una ruta compatible para este traslado.";
        continue;
      }
      const origen = coordenadasPorCP.get(fila.datos.origenCodigoPostal);
      const destino = coordenadasPorCP.get(fila.datos.destinoCodigoPostal);
      if (!origen || !destino) {
        fila.errorCotizacion = "Coordenadas no disponibles para este traslado.";
        continue;
      }
      rutas.set(fila.indice, { origen, destino, distanciaKm: ruta.distanciaKm, tiempoHoras: ruta.tiempoHoras });
    }

    // Geocodificar el lote puede tardar varios minutos: una hora inicialmente
    // válida puede haber vencido. Revalidar antes de cotizar y preparar el cobro.
    for (const fila of filas) {
      const errorFecha = validarFila(fila.datos, fila.indice).errores.fecha_hora_programada;
      if (errorFecha) {
        fila.errores.fecha_hora_programada = errorFecha;
        fila.estado = "error";
      }
    }
    if (!permitirParcial && filas.some(f => f.estado === "error" || f.errorCotizacion)) return NextResponse.json({ filas });
    const filasParaTarifa = filas.filter(f => f.estado !== "error" && !f.errorCotizacion && rutas.has(f.indice));
    if (filasParaTarifa.length === 0) {
      return NextResponse.json({ filas, error: "Ninguna fila tiene ruta válida para cotizar." }, { status: 422 });
    }
    const tarifas = await previsualizarTarifasMasivasUsuario(cliente, filasParaTarifa.map(f => {
      const r = rutas.get(f.indice)!;
      const fechaHora = f.datos.modalidad_programacion === "programado" && f.datos.fecha_hora_programada
        ? f.datos.fecha_hora_programada
        : momento;
      return { indice: f.indice, marca: f.datos.marca, modelo: f.datos.modelo, condicion: f.datos.condicion, distanciaKm: r.distanciaKm, tiempoEstimadoHoras: r.tiempoHoras, fechaHora };
    }));
    const tarifasPorIndice = new Map(tarifas.map(t => [t.indice, t]));
    for (const fila of filasParaTarifa) {
      const d = fila.datos;
      const ruta = rutas.get(fila.indice)!;
      const { origen, destino } = ruta;
      const tarifa = tarifasPorIndice.get(fila.indice)!;
      if (!tarifa.disponible || !tarifa.tarifa || tarifa.tarifa <= 0 || !tarifa.categoria_tarifa || !tarifa.gama) {
        fila.errorCotizacion = tarifa.motivo ?? "No hay tarifa disponible para este vehículo y ruta.";
        continue;
      }
        const precio = Math.round(tarifa.tarifa * 100);
        centavos += precio;
        const n: Record<string, string> = {
          vehiculo_marca: d.marca, vehiculo_modelo: d.modelo, vehiculo_anio: d.anio,
          vehiculo_tipo: tipoSugeridoParaVehiculo(d.marca, d.modelo) ?? "sedan",
          categoria_tarifa: tarifa.categoria_tarifa, gama: tarifa.gama, condicion: d.condicion,
          contacto_entrega_nombre: d.entregaNombre, contacto_entrega_telefono: `+52${d.entregaTelefono}`,
          contacto_recepcion_nombre: d.recepcionNombre, contacto_recepcion_telefono: `+52${d.recepcionTelefono}`,
          origen_direccion: [d.origen_calle, d.origen_numero, d.origen_colonia, d.origenCodigoPostal].filter(Boolean).join(", "),
          destino_direccion: [d.destino_calle, d.destino_numero, d.destino_colonia, d.destinoCodigoPostal].filter(Boolean).join(", "),
          origen_ciudad: d.origen_municipio || d.origenCodigoPostal, destino_ciudad: d.destino_municipio || d.destinoCodigoPostal,
          origen_lng: String(origen[0]), origen_lat: String(origen[1]), destino_lng: String(destino[0]), destino_lat: String(destino[1]),
          distancia_km: String(ruta.distanciaKm), tiempo_estimado_horas: String(ruta.tiempoHoras),
          modalidad_programacion: d.modalidad_programacion || "lo_antes_posible",
        };
        for (const key of ["referencia_externa", "vehiculo_placas", "vehiculo_vin", "vehiculo_color", "vehiculo_transmision", "estado_general_declarado", "origen_referencias", "destino_referencias", "fecha_hora_programada", "instrucciones_especiales"]) if (d[key]) n[key] = d[key]!;
        n.tipo_ruta = d.tipo_traslado || "local";
        n.instrucciones_especiales = [n.instrucciones_especiales, ...["centro_costo", "orden_compra", "prioridad", "ventana_recoleccion", "ventana_recoleccion_horario", "ventana_entrega", "ventana_entrega_horario"].filter(k => d[k]).map(k => `${k}: ${d[k]}`)].filter(Boolean).join(" | ");
        normalizadas.push(n);
        cotizaciones.push({ ...fila, tarifa: precio / 100, distanciaKm: ruta.distanciaKm });
    }
    if (!permitirParcial && filas.some(f => f.errorCotizacion)) return NextResponse.json({ filas });
    if (normalizadas.length === 0) return NextResponse.json({ filas, error: "Ninguna fila pudo cotizarse." }, { status: 422 });
    const servicio = clienteMasivoServicio();
    const id = body.data.clave;
    const routeHash = hashRuta(normalizadas);
    const filasErroneas = filas.filter(f => f.estado === "error" || f.errorCotizacion);
    const filasPendientesCorreccion = filasErroneas.map(f => f.datos);
    const guardado = await guardarCheckoutMasivoServidor(servicio, {
      id,
      auth_user_id: user.id,
      filas: normalizadas,
      cotizaciones,
      monto_centavos: centavos,
      filas_pendientes_correccion: filasPendientesCorreccion,
      idempotency_key: id,
      route_hash: routeHash,
    });
    let intent;
    let stripeCreado = false;
    try {
      const reserva = await reservarCheckoutMasivoServidor(servicio, {
        id,
        authId: user.id,
        idempotencyKey: id,
        routeHash,
        montoCentavos: guardado.monto_centavos,
      });
      if (reserva.estado === "en_progreso") {
        return NextResponse.json({ error: "Esta carga ya está siendo procesada. Consulta su estado antes de reintentar." }, { status: 409 });
      }
      if (reserva.estado === "payment_intent_existente") {
        intent = await stripeMasivo(`payment_intents/${encodeURIComponent(reserva.payment_intent_id)}`);
        return NextResponse.json({ id, clientSecret: intent.client_secret, totalMXN: guardado.monto_centavos / 100, cotizaciones: guardado.cotizaciones, filasConError: filasErroneas, filasPendientesCorreccion, parcial: permitirParcial && filasErroneas.length > 0 });
      }
      const customer = await obtenerClienteBilleteraServidor(servicio, user.id, /^(sk|rk)_test_/.test(process.env.STRIPE_SECRET_KEY ?? "") ? "test" : "live");
      intent = await stripeMasivo("payment_intents", new URLSearchParams({ amount: String(guardado.monto_centavos), currency: "mxn", "automatic_payment_methods[enabled]": "true", "metadata[carga_masiva_id]": id, ...(customer ? { customer } : {}) }), `carga-masiva-${id}`);
      stripeCreado = true;
      await vincularPagoMasivoServidor(servicio, id, user.id, intent.id);
    } catch (stripeErr) {
      // Transacción de compensación: si falla Stripe al crear o vincular el PaymentIntent,
      // eliminamos de inmediato el registro en base de datos para no dejar checkouts huérfanos sin pago.
      try {
        if (stripeCreado) throw stripeErr;
        await eliminarCheckoutMasivoServidor(servicio, id, user.id);
      } catch (compensacionErr) {
        logStructuredError("api/viajes/masivos/cotizar", "compensacion_checkout_fallida", compensacionErr, {
          cargaId: id,
          usuarioId: user.id,
        });
      }
      throw stripeErr;
    }

    registrarMetricaCotizacion({
      clave: id,
      totalFilas: filas.length,
      cotizadas: normalizadas.length,
      erroresRuta: filasErroneas.length,
      duracionMs: performance.now() - inicioCotizacion,
      montoCentavos: centavos,
      parcial: permitirParcial && filasErroneas.length > 0,
      usuarioId: user.id,
    });

    return NextResponse.json({
      id,
      clientSecret: intent.client_secret,
      totalMXN: guardado.monto_centavos / 100,
      cotizaciones: guardado.cotizaciones,
      filasConError: filasErroneas,
      filasPendientesCorreccion,
      parcial: permitirParcial && filasErroneas.length > 0,
    });
  } catch (err) {
    logStructuredError("api/viajes/masivos/cotizar", "cotizacion_masiva_fallida", err, {
      usuarioId: user.id,
    });
    if (err instanceof ErrorServicioCotizacion) return NextResponse.json({ error: err.message }, { status: err.status });
    if (err instanceof Error && err.message === "MASIVOS_CPU_BUDGET_EXCEEDED") return NextResponse.json({ error: "La carga excedió el tiempo máximo de procesamiento. Reduce el lote e intenta de nuevo." }, { status: 503, headers: { "Retry-After": "60" } });
    if (err && typeof err === "object" && "message" in err && String(err.message).includes("RATE_LIMITED")) return NextResponse.json({ error: "Alcanzaste el límite de cotizaciones masivas. Espera un minuto y reintenta." }, { status: 429, headers: { "Retry-After": "60" } });
    return NextResponse.json({ error: err instanceof Error ? err.message : "No se pudo cotizar la carga." }, { status: 503 });
  }
}
