import Link from "next/link";
import Image from "next/image";
import type { ReactNode } from "react";
import { Aviso, Button, Icono, PassportCard, SENDAS_ICONO, MobileShell } from "@ruum/ui";
import { ETIQUETA_TIPO_VEHICULO } from "@ruum/shared/constants";
import type { Database } from "@ruum/shared/types";
import type { RolEfectivoCuentaDTO } from "@ruum/api/services";
import { PerfilCuentaForm } from "./PerfilCuentaForm";
import { BotonResetPassword } from "./BotonResetPassword";
import { FacturacionCuentaForm } from "./FacturacionCuentaForm";
import { iniciales } from "./cuenta-utils";
import { BotonReintentarSesion } from "../ReintentarSesion";
import { NavegacionUsuario } from "../NavegacionUsuario";

export { iniciales } from "./cuenta-utils";
export {
  enmascararRfc,
  enmascararVin,
  enmascararTelefono,
  enmascararCreditoEmpresarial,
  enmascararDireccionResumen,
} from "@ruum/api/services";

export type Usuario = Database["public"]["Tables"]["usuarios"]["Row"];
export type Vehiculo = Database["public"]["Tables"]["vehiculos"]["Row"];
export type Empresa = Database["public"]["Tables"]["empresas"]["Row"];

export interface CuentaReal {
  usuario: Usuario;
  correoRegistro?: string | null;
  fotoPerfilUrl: string | null;
  vehiculos: Vehiculo[];
  empresa: Empresa | null;
  totalTraslados: number;
  datosAuxiliaresCargados?: boolean;
  auxiliaresConFallo?: string[];
  fotoPerfilNoDisponible?: boolean;
  incidenciasAbiertas?: number;
  traslados?: Database["public"]["Views"]["pasaporte_digital"]["Row"][];
  rolInfo?: RolEfectivoCuentaDTO;
}

const LINKS_CUENTA = [
  { href: "/cuenta/datos-personales", inicial: "D", titulo: "Datos personales", descripcion: "Edita tu información personal y dirección." },
  { href: "/cuenta/vehiculos", inicial: "V", titulo: "Mis vehículos", descripcion: "Autos frecuentes, placas, VIN y fotografías." },
];

const LINKS_VERIFICACION = [
  { href: "/cuenta/verificacion-documentos", inicial: "V", titulo: "Verificación y facturación", descripcion: "INE, licencia, comprobante y datos fiscales." },
];

const LINKS_PREFERENCIAS = [
  { href: "/cuenta/preferencias", inicial: "N", titulo: "Preferencias", descripcion: "Notificaciones y alertas." },
];

const LINKS_LEGAL = [
  { href: "/cuenta/legal", inicial: "D", titulo: "Legal", descripcion: "Documentos, términos y aviso de privacidad." },
];

const DOCUMENTOS_LEGALES = {
  terminos: { pagina: "/legal/terminos", descarga: "/docs-legales/terminos-y-condiciones-ruum-ruum.docx" },
  privacidad: { pagina: "/legal/privacidad", descarga: "/docs-legales/aviso-de-privacidad-ruum-ruum.docx" },
};

/* Etiquetas legibles para estado_verificacion — reemplaza replace("_", " ")
 * que solo corregía el primer guión y dejaba estados como "usuario pendiente_verificacion". */
const ETIQUETA_VERIFICACION: Record<string, string> = {
  pendiente: "Pendiente de verificación",
  en_revision: "En revisión",
  verificado: "Verificado",
  rechazado: "Documentación rechazada",
  usuario_pendiente_verificacion: "Pendiente de verificación",
};

function etiquetaVerificacion(estado: string): string {
  return ETIQUETA_VERIFICACION[estado] ?? estado.replaceAll("_", " ");
}


/**
 * Resultado de cargar la cuenta.
 *
 * A-4 (auditoría): antes `obtenerCuenta` devolvía `null` tanto si no había
 * sesión como si Supabase estaba caído. Las 6 subrutas de /cuenta renderizaban
 * "Inicia sesión para consultar y actualizar los datos de tu cuenta", mandando
 * al usuario a un bucle de autenticación sin causa visible ni traza.
 * `sin_sesion` y `error` ahora son estados distintos y explícitos.
 */
export type ResultadoCuenta =
  | { estado: "ok"; cuenta: CuentaReal }
  | { estado: "sin_sesion" }
  | { estado: "error"; mensaje: string };

type OpcionesCuenta = { carga?: "completa" | "perfil" | "preferencias" };
export async function obtenerCuenta({ carga = "completa" }: OpcionesCuenta = {}): Promise<ResultadoCuenta> {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anonKey) return { estado: "sin_sesion" };

  try {
    const { crearClienteServidor } = await import("../../lib/supabase-server");
    const {
      obtenerUrlFotoPerfilUsuario,
      obtenerUsuarioActual,
      listarTrasladosDeUsuario,
      obtenerRolEfectivoUsuario,
    } = await import("@ruum/api/services");
    const { listarVehiculosDeUsuario } = await import("@ruum/api/vehicles");
    const { obtenerEmpresaVisible } = await import("@ruum/api/organizations");
    const cliente = await crearClienteServidor();
    const { data: auth, error: errorAuth } = await cliente.auth.getUser();
    if (errorAuth?.name === "AuthSessionMissingError") return { estado: "sin_sesion" };
    if (errorAuth) throw errorAuth;
    if (!auth.user) return { estado: "sin_sesion" };
    const usuario = await obtenerUsuarioActual(cliente);
    if (!usuario) return { estado: "sin_sesion" };

    let fotoPerfilNoDisponible = false;
    const fotoPerfilUrl = carga === "preferencias" ? null : await obtenerUrlFotoPerfilUsuario(cliente, usuario.foto_url).catch(error => {
      if (carga === "completa") throw error;
      fotoPerfilNoDisponible = true;
      console.warn("[cuenta] no se pudo cargar la foto de perfil", error);
      return null;
    });

    // Editar el perfil o preferencias no depende del historial, garaje o empresa.
    if (carga !== "completa") return {
      estado: "ok",
      cuenta: {
        usuario,
        correoRegistro: auth.user.email ?? null,
        fotoPerfilUrl,
        fotoPerfilNoDisponible,
        vehiculos: [],
        empresa: null,
        totalTraslados: 0,
        datosAuxiliaresCargados: false,
        auxiliaresConFallo: [],
      },
    };

    // Orden de carga: esencial resuelto (usuario + auth), diferido en paralelo resiliente (Promise.allSettled)
    const [resVehiculos, resEmpresa, resTraslados, resRol] = await Promise.allSettled([
      listarVehiculosDeUsuario(cliente, usuario.id),
      usuario.empresa_id ? obtenerEmpresaVisible(cliente, usuario.empresa_id) : Promise.resolve(null),
      listarTrasladosDeUsuario(cliente, usuario.id),
      obtenerRolEfectivoUsuario(cliente, auth.user.id),
    ]);

    const auxiliaresConFallo: string[] = [];

    const vehiculos = resVehiculos.status === "fulfilled" ? resVehiculos.value : (auxiliaresConFallo.push("vehiculos"), []);
    const empresa = resEmpresa.status === "fulfilled" ? resEmpresa.value : (auxiliaresConFallo.push("empresa"), null);
    const trasladosPropios = resTraslados.status === "fulfilled" ? resTraslados.value : (auxiliaresConFallo.push("traslados"), []);
    const rolInfo = resRol.status === "fulfilled" ? resRol.value : (auxiliaresConFallo.push("rol"), undefined);

    if (auxiliaresConFallo.length > 0) {
      console.warn("[cuenta] servicios_auxiliares_con_fallo_diferido", {
        usuario_id: usuario.id,
        fallos: auxiliaresConFallo,
      });
    }

    return {
      estado: "ok",
      cuenta: {
        usuario,
        correoRegistro: auth.user.email ?? null,
        fotoPerfilUrl,
        vehiculos,
        empresa,
        totalTraslados: trasladosPropios.length,
        incidenciasAbiertas: trasladosPropios.reduce((total, traslado) => total + (traslado.incidencias_abiertas ?? 0), 0),
        traslados: trasladosPropios,
        datosAuxiliaresCargados: auxiliaresConFallo.length === 0,
        auxiliaresConFallo,
        rolInfo,
      }
    };
  } catch (err) {
    // No tragamos el error: queda traza para soporte y el usuario ve un estado
    // de fallo real en vez de un formulario de login que no va a funcionar.
    console.error("[cuenta] no se pudo cargar la cuenta del usuario", err);
    return {
      estado: "error",
      mensaje: "No pudimos cargar tu cuenta en este momento. Inténtalo de nuevo en unos segundos."
    };
  }
}

export function dato(valor: string | number | null | undefined) {
  return valor ? String(valor) : "Pendiente";
}

export function Campo({ etiqueta, valor }: { etiqueta: string; valor?: string | null | undefined }) {
  return (
    <div>
      <dt className="font-body text-xs uppercase tracking-wide font-medium text-[var(--user-color-muted)]">{etiqueta}</dt>
      <dd className="mt-1 font-body text-sm font-semibold text-[var(--user-color-primary)]">{dato(valor)}</dd>
    </div>
  );
}

export function Seccion({
  titulo,
  descripcion,
  children
}: {
  titulo: string;
  descripcion?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="user-v2-card p-5 sm:p-6">
      <div className="flex flex-col gap-1">
        <h2 className="user-v2-heading-2">{titulo}</h2>
        {descripcion && <p className="user-v2-caption user-v2-muted">{descripcion}</p>}
      </div>
      <div className="mt-6">{children}</div>
    </div>
  );
}

function FilaConfiguracion({
  href,
  titulo,
  descripcion,
  detalle,
  inicial
}: {
  href: string;
  titulo: string;
  descripcion?: string;
  detalle?: string;
  inicial: string;
}) {
  return (
    <Link
      href={href}
      className="user-v2-card user-v2-card-interactive group flex items-center gap-3.5 px-4 py-4 font-body text-sm"
    >
      <span className="flex size-10 shrink-0 items-center justify-center rounded-lg border border-[var(--user-color-action)]/30 bg-[var(--user-color-action)]/10 font-display text-sm font-bold text-[var(--user-color-action)]">
        {inicial}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block font-display text-sm font-bold leading-tight text-[var(--user-color-primary)]">{titulo}</span>
        {descripcion && <span className="mt-1 block text-xs leading-4 text-[var(--user-color-muted)]">{descripcion}</span>}
      </span>
      {detalle && <span className="shrink-0 rounded-full border border-[var(--user-color-action)]/30 bg-[var(--user-color-action)]/10 px-2 py-0.5 text-xs font-semibold text-[var(--user-color-action)]">{detalle}</span>}
      <span className="text-lg leading-none text-[var(--user-color-muted)] transition-transform group-hover:translate-x-0.5 group-hover:text-[var(--user-color-brand)]">›</span>
    </Link>
  );
}

function GrupoConfiguracion({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-2 font-mono-ruum text-xs font-semibold uppercase tracking-wider text-[var(--user-color-action)]">{titulo}</p>
      <div className="grid gap-3 sm:grid-cols-2">{children}</div>
    </div>
  );
}

/**
 * Aviso de fallo de carga (A-4). Distinto de AvisoSinSesion: aquí el usuario
 * SÍ está autenticado y reintentar tiene sentido; ofrecer "Iniciar sesión"
 * lo llevaría a un bucle sin solución.
 */
export function AvisoErrorCuenta({ mensaje }: { mensaje?: string | null }) {
  return (
    <>
      <NavegacionUsuario variante="claro" />
      <MobileShell variant="compact" navInferiorVisible={true} as="main" className="user-v2-scope user-account-shell" contentClassName="user-account-content">
        <div className="user-account-fallback text-center">
          <Aviso tono="danger">
            {mensaje ?? "No pudimos cargar tu cuenta en este momento. Inténtalo de nuevo en unos segundos."}
          </Aviso>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row justify-center">
            <BotonReintentarSesion />
            <Link href="/soporte">
              <Button className="w-full sm:w-auto">Reportar un problema</Button>
            </Link>
            <Link href="/">
              <Button variant="secondary" className="w-full sm:w-auto">Ir al inicio</Button>
            </Link>
          </div>
        </div>
      </MobileShell>
    </>
  );
}

/**
 * Resuelve obtenerCuenta() y devuelve el JSX de estado, o null si hay cuenta.
 * Evita que cada subruta tenga que repetir el switch de tres casos.
 */
export async function conCuenta(
  render: (cuenta: CuentaReal) => ReactNode,
  opciones: OpcionesCuenta = {}
): Promise<ReactNode> {
  const resultado = await obtenerCuenta(opciones);
  if (resultado.estado === "error") return <AvisoErrorCuenta mensaje={resultado.mensaje} />;
  if (resultado.estado === "sin_sesion") return <AvisoSinSesion />;
  return render(resultado.cuenta);
}

export function AvisoSinSesion() {
  return (
    <>
      <NavegacionUsuario variante="claro" />
      <MobileShell variant="compact" navInferiorVisible={true} as="main" className="user-v2-scope user-account-shell" contentClassName="user-account-content">
        <div className="user-account-fallback text-center">
          <Aviso tono="info">Inicia sesión para consultar y actualizar los datos de tu cuenta.</Aviso>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row justify-center">
            <Link href="/login?next=/cuenta">
              <Button className="w-full sm:w-auto">Iniciar sesión</Button>
            </Link>
            <Link href="/registro">
              <Button variant="secondary" className="w-full sm:w-auto">Crear cuenta</Button>
            </Link>
          </div>
        </div>
      </MobileShell>
    </>
  );
}

export function HeaderCuenta({ usuario, fotoUrl }: { usuario?: Usuario; fotoUrl?: string | null }) {
  return (
    <header className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <Link href="/" className="inline-flex min-h-11 items-center font-body text-sm font-medium text-[var(--user-color-muted)] underline-offset-4 hover:text-[var(--user-color-primary)] hover:underline">
          ← Volver al inicio
        </Link>
        <h1 className="mt-2 font-display text-2xl sm:text-3xl font-black leading-tight text-text-primary">Cuenta</h1>
        <p className="mt-1 max-w-2xl font-body text-sm text-text-secondary">
          Administra tu perfil, vehículos frecuentes, métodos de pago y datos de facturación.
        </p>
      </div>
      <div className="hidden sm:block">
        <Link href="/soporte">
          <Button variant="secondary" className="font-display font-semibold text-xs">¿Necesitas ayuda?</Button>
        </Link>
      </div>
      {usuario && (
        <div className="flex items-center gap-3 sm:hidden">
          {fotoUrl ? (
            <Image src={fotoUrl} alt="Foto de perfil" width={48} height={48} className="size-12 rounded-full object-cover" />
          ) : (
            <div className="flex size-12 items-center justify-center rounded-full bg-route-action/15 font-display text-sm font-bold text-route-action border border-route-action/30">
              {iniciales(usuario.nombre)}
            </div>
          )}
          <div>
            <p className="font-body text-sm font-bold text-text-primary">{dato(usuario.nombre)}</p>
            <p className="font-body text-xs text-text-secondary">{etiquetaVerificacion(usuario.estado_verificacion)}</p>
          </div>
        </div>
      )}
    </header>
  );
}

export function NavegacionCuenta({ usuario }: { usuario: Usuario }) {
  const detallePreferencias =
    usuario.notificaciones_push || usuario.notificaciones_email || usuario.notificaciones_sms_whatsapp ? "Activas" : "Pausadas";

  return (
    <section className="mb-6">
      <PassportCard>
        <div className="grid gap-5">
          <GrupoConfiguracion titulo="Cuenta">
            {LINKS_CUENTA.map((link) => (
              <FilaConfiguracion key={link.href} {...link} />
            ))}
          </GrupoConfiguracion>
          <GrupoConfiguracion titulo="Verificación">
            {LINKS_VERIFICACION.map((link) => (
              <FilaConfiguracion key={link.href} {...link} />
            ))}
          </GrupoConfiguracion>
          <GrupoConfiguracion titulo="Preferencias">
            {LINKS_PREFERENCIAS.map((link) => (
              <FilaConfiguracion key={link.href} {...link} detalle={link.href === "/cuenta/preferencias" ? detallePreferencias : undefined} />
            ))}
          </GrupoConfiguracion>
          <GrupoConfiguracion titulo="Legal">
            {LINKS_LEGAL.map((link) => (
              <FilaConfiguracion key={link.href} {...link} />
            ))}
            <FilaConfiguracion href={DOCUMENTOS_LEGALES.terminos.pagina} inicial="T" titulo="Términos y condiciones" descripcion="Reglas de uso, pagos, cancelaciones y servicio." />
            <FilaConfiguracion href={DOCUMENTOS_LEGALES.privacidad.pagina} inicial="A" titulo="Aviso de privacidad" descripcion="Tratamiento de datos e identidad." />
          </GrupoConfiguracion>
        </div>
      </PassportCard>
    </section>
  );
}

export function LayoutCuenta({ cuenta, children }: { cuenta: CuentaReal; children: React.ReactNode }) {
  return (
    <>
      <NavegacionUsuario variante="claro" />
      <main className="user-v2-scope user-v2-page user-v2-secondary-screen"><div className="user-v2-content user-v2-content--wide py-10 sm:py-14">
        <HeaderCuenta usuario={cuenta.usuario} fotoUrl={cuenta.fotoPerfilUrl} />
        <NavegacionCuenta usuario={cuenta.usuario} />
        {children}
      </div>
    </main>
    </>
  );
}

function IconoSeccion({ d }: { d: string }) {
  return <Icono d={d} className="size-3.5" />;
}

function TarjetaSeccion({
  id,
  icono,
  titulo,
  children,
}: {
  id?: string;
  icono: string;
  titulo: string;
  children: React.ReactNode;
}) {
  return (
    <section
      id={id}
      aria-label={titulo}
      className="scroll-mt-28 rounded-[22px] border border-[#eef2f7] bg-white p-5 shadow-[0_6px_16px_rgba(0,0,0,0.01)]"
    >
      <h2 className="mb-4 flex items-center gap-2.5 text-[16px] font-bold text-[#0a2342]">
        <span aria-hidden="true" className="flex size-7 items-center justify-center rounded-[10px] bg-[#f0f5fe] text-[#2e5a88]">
          <IconoSeccion d={icono} />
        </span>
        {titulo}
      </h2>
      {children}
    </section>
  );
}

function FilaDato({ etiqueta, valor }: { etiqueta: string; valor: React.ReactNode }) {
  return (
    <div className="flex items-start text-[14px] leading-snug">
      <span className="w-[130px] shrink-0 font-medium text-[#6f7e94]">{etiqueta}</span>
      <span className="flex-1 font-semibold text-[#1a293b]">{valor}</span>
    </div>
  );
}

export function SeccionPerfil({ usuario, fotoUrl }: { usuario: Usuario; fotoUrl?: string | null }) {
  const verificado = usuario.estado_verificacion === "verificado";
  return (
    <div className="flex flex-col gap-4">
      <Link
        href="/cuenta"
        aria-label="Volver a Cuenta"
        className="inline-flex min-h-11 items-center gap-2.5 text-[14px] font-bold text-[#2e5a88]"
      >
        <span aria-hidden="true" className="flex size-10 items-center justify-center rounded-full bg-[#f2f6fc] text-[#0a2342]">
          <Icono nombre="atras" className="size-[18px]" strokeWidth={2} />
        </span>
        Volver
      </Link>

      <TarjetaSeccion
        id="informacion-personal"
        icono={SENDAS_ICONO.usuario}
        titulo="Información personal"
      >
        <div className="mb-4 flex items-center gap-4">
          {fotoUrl ? (
            <Image src={fotoUrl} alt="Foto de perfil" width={80} height={80} className="size-20 shrink-0 rounded-full border-2 border-white object-cover shadow-[0_4px_12px_rgba(0,0,0,0.05)]" />
          ) : (
            <span aria-hidden="true" className="flex size-20 shrink-0 items-center justify-center rounded-full border-2 border-white bg-[#d1ddeb] font-display text-2xl font-bold text-[#0a2342] shadow-[0_4px_12px_rgba(0,0,0,0.05)]">
              {iniciales(usuario.nombre)}
            </span>
          )}
          <div className="min-w-0">
            <p className="truncate font-body text-lg font-bold text-[#0a2342]">{dato(usuario.nombre)}</p>
            <p className="mt-1">
              <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold ${verificado ? "bg-[#e9f3ee] text-[#1f6b4a]" : "bg-[#eef3fa] text-[#2e5a88]"}`}>
                {etiquetaVerificacion(usuario.estado_verificacion)}
              </span>
            </p>
          </div>
        </div>
        <div className="flex flex-col gap-3">
          <FilaDato etiqueta="Nombre" valor={dato(usuario.nombre)} />
          <FilaDato etiqueta="Correo" valor={dato(usuario.correo_facturacion)} />
          <FilaDato etiqueta="Teléfono" valor={dato(usuario.telefono)} />
          <FilaDato
            etiqueta="Cuenta"
            valor={usuario.tipo_cuenta === "empresa" ? "Empresarial" : "Personal"}
          />
        </div>
      </TarjetaSeccion>

      <TarjetaSeccion
        id="contacto"
        icono="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7 M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5Z"
        titulo="Contacto y dirección"
      >
        <PerfilCuentaForm usuario={usuario} fotoUrlInicial={fotoUrl} />
      </TarjetaSeccion>

      <TarjetaSeccion
        id="acceso"
        icono="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z M9 12l2 2 4-4"
        titulo="Verificación de identidad"
      >
        <p className="font-body text-sm text-[#4d6079]">Estado actual: {etiquetaVerificacion(usuario.estado_verificacion)}.</p>
        <div className="mt-4">
          <Link href="/verificacion">
            <Button variant="secondary">{usuario.doc_identidad_url ? "Actualizar identificación" : "Subir identificación"}</Button>
          </Link>
        </div>
      </TarjetaSeccion>

      <TarjetaSeccion
        id="seguridad"
        icono={SENDAS_ICONO.candado}
        titulo="Contraseña"
      >
        <p className="font-body text-sm text-[#4d6079]">
          Te enviaremos un enlace a tu correo para crear una nueva contraseña de forma segura.
        </p>
        <div className="mt-4">
          <BotonResetPassword />
        </div>
      </TarjetaSeccion>
    </div>
  );
}

export function SeccionVehiculos({ vehiculos }: { vehiculos: Vehiculo[] }) {
  return (
    <Seccion titulo="Mis vehículos" descripcion="Guarda vehículos frecuentes para acelerar solicitudes futuras.">
      <div className="grid gap-4 md:grid-cols-2">
        {vehiculos.length > 0 ? (
          vehiculos.map((vehiculo) => (
            <div key={vehiculo.id} className="user-v2-card px-4 py-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-body text-xs uppercase tracking-wide text-[var(--user-color-muted)]">{vehiculo.alias || "Vehículo frecuente"}</p>
                  <h3 className="mt-1 font-display text-lg font-semibold text-[var(--user-color-primary)]">
                    {vehiculo.marca} {vehiculo.modelo} {vehiculo.anio}
                  </h3>
                </div>
                <span className="rounded-full border border-[var(--user-color-border)] px-2.5 py-1 font-body text-xs text-[var(--user-color-muted)]">
                  {ETIQUETA_TIPO_VEHICULO[vehiculo.tipo]}
                </span>
              </div>
              {vehiculo.fotos_urls.length > 0 ? (
                <div className="mt-4 grid grid-cols-3 gap-2">
                  {vehiculo.fotos_urls.slice(0, 3).map((foto) => (
                    <Image key={foto} src={foto} alt={vehiculo.alias ?? vehiculo.modelo} width={200} height={150} className="aspect-[4/3] rounded-lg object-cover" />
                  ))}
                </div>
              ) : (
                <div className="mt-4 flex aspect-[5/2] items-center justify-center rounded-lg border border-dashed border-[var(--user-color-border)] bg-[var(--user-color-surface-soft)] font-body text-sm text-[var(--user-color-muted)]">
                  Sin fotografías guardadas
                </div>
              )}
              <dl className="mt-4 grid gap-3 sm:grid-cols-2">
                <Campo etiqueta="Color" valor={vehiculo.color} />
                <Campo etiqueta="Placas" valor={vehiculo.placas} />
                <Campo etiqueta="VIN" valor={vehiculo.vin} />
                <Campo etiqueta="Transmisión" valor={vehiculo.transmision} />
              </dl>
            </div>
          ))
        ) : (
          <div className="rounded-lg border border-dashed border-ink/15 px-4 py-6 font-body text-sm text-ink/55">
            Aún no tienes vehículos frecuentes guardados.
          </div>
        )}
      </div>
      <div className="mt-5">
        <Link href="/viajes/nuevo">
          <Button variant="secondary">Agregar desde una solicitud</Button>
        </Link>
      </div>
    </Seccion>
  );
}

export function SeccionFacturacion({ usuario, empresa }: { usuario: Usuario; empresa: Empresa | null }) {
  return (
    <Seccion titulo="Facturación" descripcion="Captura los datos fiscales para comprobantes y cuentas empresariales.">
      <FacturacionCuentaForm usuario={usuario} empresa={empresa} />
    </Seccion>
  );
}

export function SeccionLegal() {
  return (
    <Seccion titulo="Legal" descripcion="Documentos y condiciones vigentes de Ruum Ruum.">
      <div className="grid gap-3">
        {/* Página HTML accesible + descarga .docx opcional */}
        <div className="flex items-center justify-between rounded-lg border border-[var(--user-color-border)] bg-[var(--user-color-surface)] px-4 py-3">
          <Link href={DOCUMENTOS_LEGALES.terminos.pagina} className="font-body text-sm font-semibold text-[var(--user-color-primary)] hover:text-[var(--user-color-action)]">
            Términos y condiciones
          </Link>
          <a
            href={DOCUMENTOS_LEGALES.terminos.descarga}
            download
            className="font-body text-xs text-[var(--user-color-muted)] underline-offset-2 hover:underline"
            aria-label="Descargar términos y condiciones en Word"
          >
            .docx
          </a>
        </div>
        <div className="flex items-center justify-between rounded-lg border border-[var(--user-color-border)] bg-[var(--user-color-surface)] px-4 py-3">
          <Link href={DOCUMENTOS_LEGALES.privacidad.pagina} className="font-body text-sm font-semibold text-[var(--user-color-primary)] hover:text-[var(--user-color-action)]">
            Aviso de privacidad
          </Link>
          <a
            href={DOCUMENTOS_LEGALES.privacidad.descarga}
            download
            className="font-body text-xs text-[var(--user-color-muted)] underline-offset-2 hover:underline"
            aria-label="Descargar aviso de privacidad en Word"
          >
            .docx
          </a>
        </div>
      </div>
    </Seccion>
  );
}
