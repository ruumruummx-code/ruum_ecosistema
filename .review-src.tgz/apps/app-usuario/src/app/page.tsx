import Link from "next/link";
import { FormularioPropuestaEmpresa } from "./FormularioPropuestaEmpresa";
import Image from "next/image";
import { redirect } from "next/navigation";
import type { Database } from "@ruum/shared/types";
import { IDENTIDAD_MARCA } from "@ruum/shared/constants";
import { LogoMarca, SelloConductor, Icono, MobileShell } from "@ruum/ui";
import { NavegacionUsuario } from "./NavegacionUsuario";
import { InicioMobile, InicioDesktop } from "./InicioUsuario";
import { BotonReintentarSesion } from "./ReintentarSesion";
import { EnlaceRecorridoGuiado } from "./EnlaceRecorridoGuiado";
import { construirNotificaciones } from "../lib/inicio";
import { logStructuredWarn } from "../lib/logger";
import { botonAzul, botonContorno } from "./experiencia-publica";
import { PUBLIC_CLAIMS, PUBLIC_CLAIMS_VERSION } from "../lib/public-claims";
// RC-14: estilos responsivos del dashboard (ver InicioUsuario.css).
import "./InicioUsuario.css";

type UsuarioRow = Database["public"]["Tables"]["usuarios"]["Row"];
type PasaporteRow = Database["public"]["Views"]["pasaporte_digital"]["Row"];
type VehiculoRow = Database["public"]["Tables"]["vehiculos"]["Row"];

interface ContextoSesion {
  sesionActiva: boolean;
  usuario: UsuarioRow | null;
  traslados: PasaporteRow[];
  vehiculos: VehiculoRow[];
  conductorFotoUrl: string | null;
  error?: string | null;
  errorVehiculos?: boolean;
}

async function obtenerContextoSesion(): Promise<ContextoSesion> {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anonKey) return { sesionActiva: false, usuario: null, traslados: [], vehiculos: [], conductorFotoUrl: null, error: "config_error" };

  try {
    const { crearClienteServidor } = await import("../lib/supabase-server");
    const { obtenerUsuarioActual, listarResumenTrasladosDeUsuario } = await import("@ruum/api/services");
    const { listarVehiculosDeUsuario } = await import("@ruum/api/vehicles");

    const cliente = await crearClienteServidor();
    const { data: { user } } = await cliente.auth.getUser();
    if (!user) return { sesionActiva: false, usuario: null, traslados: [], vehiculos: [], conductorFotoUrl: null };
    const usuario = await obtenerUsuarioActual(cliente);
    if (!usuario) return { sesionActiva: true, usuario: null, traslados: [], vehiculos: [], conductorFotoUrl: null };

    let errorVehiculos = false;
    const [traslados, vehiculos] = await Promise.all([
      listarResumenTrasladosDeUsuario(cliente, usuario.id, { limite: 6 }),
      listarVehiculosDeUsuario(cliente, usuario.id).catch((err) => {
        errorVehiculos = true;
        logStructuredWarn("obtenerContextoSesion", "vehiculos_no_disponibles", err, {
          usuarioId: usuario.id,
        });
        return [];
      }),
    ]);
    // La foto del conductor se solicita de forma diferida desde el dashboard;
    // no debe bloquear el primer render del resumen.
    return { sesionActiva: true, usuario, traslados, vehiculos, conductorFotoUrl: null, errorVehiculos, error: null };
  } catch (err) {
    console.error("[app-usuario:obtenerContextoSesion] supabase_error", {
      message: err instanceof Error ? err.message : String(err),
    });
    return { sesionActiva: false, usuario: null, traslados: [], vehiculos: [], conductorFotoUrl: null, error: "supabase_error" };
  }
}

export default async function PaginaInicio({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = (await searchParams) ?? {};
  const { sesionActiva, usuario, traslados, vehiculos, conductorFotoUrl, error, errorVehiculos } = await obtenerContextoSesion();
  const forzarLanding = params.landing === "true";

  // C-08: no silenciar error de Supabase — mostrar Aviso en lugar de landing/redirect confuso
  if (error && sesionActiva && !usuario) {
    const esConfigError = error === "config_error";
    return (
      <>
        <NavegacionUsuario variante="claro" />
        <MobileShell variant="compact" navInferiorVisible={true}>
          <div className="user-v2-card p-6 text-center" role="alert" aria-live="assertive">
            <p className="font-display text-xs font-bold uppercase tracking-widest text-[var(--user-color-error)]">
              {esConfigError ? "Servicio no configurado" : "No pudimos verificar tu sesión"}
            </p>
            <h1 className="mt-2 font-display text-xl font-bold text-[var(--user-color-primary)]">
              {esConfigError ? "Configuración incompleta" : "Error temporal de conexión"}
            </h1>
            <p className="mt-2 font-body text-sm leading-6 text-[var(--user-color-muted)]">
              {esConfigError
                ? "Falta configuración de Supabase. Contacta a soporte si ves este mensaje en producción."
                : "No pudimos cargar tu sesión por un error de red. Tus datos siguen seguros; intenta recargar o inicia sesión de nuevo."}
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
              <BotonReintentarSesion />
              <Link
                href="/login"
                className="user-v2-secondary-button inline-flex items-center justify-center px-6"
              >
                Ir a iniciar sesión
              </Link>
            </div>
            <p className="mt-4 font-body text-xs text-[var(--user-color-muted)]">
              Si el problema persiste, <Link href="/soporte" className="underline hover:text-[var(--user-color-primary)]">contacta a soporte</Link>.
            </p>
          </div>
        </MobileShell>
      </>
    );
  }

  if (usuario && !forzarLanding) {
    const notificacionesCount = construirNotificaciones(usuario, traslados).length;
    return (
      <>
        {/* VISTA MÓVIL (< 1024px): Preservada idéntica bajo enfoque mobile-first */}
        <div className="lg:hidden flex flex-col h-full w-full">
          <NavegacionUsuario
            variante="claro"
            nombreUsuario={usuario.nombre}
            notificacionesCount={notificacionesCount}
          />
          <MobileShell
            as="main"
            variant="compact"
            navInferiorVisible={true}
            className="user-v2-scope user-dashboard-shell"
            contentClassName="user-dashboard-content"
          >
            <div aria-live="polite">
              <InicioMobile
                usuario={usuario}
                traslados={traslados}
                conductorFotoUrl={conductorFotoUrl}
                vehiculos={vehiculos}
              />
            </div>
          </MobileShell>
        </div>

        {/* VISTA ESCRITORIO (>= 1024px): Dashboard enriquecido */}
        <div className="hidden lg:flex h-full w-full">
          <InicioDesktop
            errorVehiculos={errorVehiculos}
            usuario={usuario}
            traslados={traslados}
            conductorFotoUrl={conductorFotoUrl}
            vehiculos={vehiculos}
          />
        </div>
      </>
    );
  }

  // Si no hay sesión activa y no se solicitó la landing explícitamente (?landing=true),
  // redirigir directamente al inicio de sesión (/login)
  if (sesionActiva && !usuario && !forzarLanding) {
    redirect("/inicio");
  }

  // Experiencia Pública / Landing (Libro de Marca V2.1 cap. 32)
  /* La landing tiene paleta fija (hero navy + secciones blancas): se ancla a los
     tokens claros para que el modo oscuro del usuario no invierta sus textos. */
  return (
    <div className="min-h-dvh bg-[var(--ruum-navy)] text-white" data-theme="light" data-claims-version={PUBLIC_CLAIMS_VERSION}>
      {/* Barra de Navegación Pública */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[var(--ruum-navy)]/95 pt-[env(safe-area-inset-top)] backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3.5 sm:px-6">
          {/* En móvil se omite la firma "DRIVEAWAY SERVICE": a 375px se solapaba con las acciones. */}
          <LogoMarca variante="simbolo" tema="oscuro" tamano={36} className="sm:hidden" />
          <LogoMarca variante="horizontal" tema="oscuro" tamano={34} className="max-sm:hidden" />
          <div className="flex shrink-0 items-center gap-1.5 sm:gap-3">
            <Link
              href="#como-funciona"
              className="hidden sm:inline-flex rounded-lg px-3 py-2 font-body text-xs font-semibold text-[#A9BCD3] transition hover:text-white"
            >
              Cómo funciona
            </Link>
            <Link
              href="/login"
              className="rounded-lg px-3.5 py-2 font-body text-xs font-semibold text-white transition hover:text-[var(--ruum-teal)]"
            >
              Iniciar sesión
            </Link>
            <Link
              href="/registro"
              className="ruum-button-primary rounded-[14px] px-4 py-2 font-body text-xs font-semibold text-white shadow-sm transition"
            >
              Crear cuenta
            </Link>
          </div>
        </div>
      </header>

      {/* 1. PORTADA / HERO (Páginas 1 & 28) */}
      <section className="relative overflow-hidden border-b border-white/10 px-4 pb-16 pt-12 sm:px-6 sm:pb-24 sm:pt-20">
        <div className="pointer-events-none absolute inset-0 opacity-20" aria-hidden="true">
          <Image
            src="/imagenes/seguridad-traslado.png"
            alt=""
            fill
            priority
            sizes="100vw"
            className="object-cover object-center"
          />
          <div className="absolute inset-0 bg-[var(--ruum-navy)]/60" />
        </div>

        <div className="relative mx-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-[var(--ruum-teal)]/40 bg-[var(--ruum-teal)]/10 px-3.5 py-1 text-xs font-semibold text-[var(--ruum-teal)] mb-6">
            <span className="size-2 rounded-full bg-[var(--ruum-teal)] animate-pulse" />
            {PUBLIC_CLAIMS.conductorCertificado}
          </div>

          <h1 className="font-display text-3xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Seguridad, evidencia y trazabilidad en cada viaje.
          </h1>

          <p className="mx-auto mt-6 max-w-2xl font-body text-base text-[#C7D5E7] sm:text-lg">
            {PUBLIC_CLAIMS.hero}
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link href="/registro" className={`sm:w-auto ${botonAzul} sm:px-8`}>
              Crear cuenta y cotizar
            </Link>
            <Link href="#como-funciona" className={`sm:w-auto ${botonContorno} sm:px-8`}>
              Conoce el servicio
            </Link>
            {/* M6: /onboarding enlace condicional según TTL */}
            <EnlaceRecorridoGuiado />
            <Link
              href="/login"
              className="inline-flex min-h-11 w-full sm:w-auto items-center justify-center rounded-lg px-5 py-3 font-display text-sm font-semibold text-[#8B98AD] transition hover:text-white"
            >
              Iniciar sesión →
            </Link>
          </div>

          <div className="mt-10 flex items-center justify-center gap-2 font-mono-ruum text-xs uppercase tracking-widest text-[#8B98AD]">
            <span>by MoviliaX</span>
            <span>•</span>
            <span>{PUBLIC_CLAIMS.cobertura}</span>
          </div>
        </div>
      </section>

      {/* 2. QUÉ HACEMOS (Página 28) */}
      <section className="border-b border-white/10 bg-[#121721] py-16 sm:py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="grid gap-10 md:grid-cols-2 md:items-center">
            <div>
              <span className="font-body text-xs font-bold uppercase tracking-wider text-[var(--ruum-teal)]">
                Esencia de marca
              </span>
              <h2 className="mt-2 font-display text-2xl font-black text-white sm:text-3xl">
                ¿Qué es Ruum Ruum?
              </h2>
              <p className="mt-4 font-body text-sm leading-relaxed text-[#B7C2D4] sm:text-base">
                {IDENTIDAD_MARCA.esencia.queEs}
              </p>
              <p className="mt-4 font-body text-sm leading-relaxed text-[#8B98AD]">
                Muchas personas entregan su vehículo sin suficiente información, sin evidencia y sin
                claridad sobre quién lo conduce. Ruum Ruum convierte el traslado vehicular en un proceso profesional documentado.
              </p>
              <div className="mt-6">
                <SelloConductor compacto tema="certificado" />
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-6 shadow-xl">
              <h3 className="font-display text-lg font-bold text-[var(--ruum-teal)]">
                Idea Central
              </h3>
              <p className="mt-2 font-display text-xl font-bold text-white">
                “No movemos vehículos a ciegas. Movemos vehículos con seguridad, evidencia y trazabilidad.”
              </p>
              <div className="mt-6 border-t border-white/10 pt-4">
                <p className="font-body text-xs text-[#B7C2D4]">
                  Diseñado para particulares, agencias automotrices, talleres mecánicos, flotillas y corporativos.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. CÓMO FUNCIONA (Protocolo Operativo de 6 Pasos · Página 28) */}
      <section id="como-funciona" className="border-b border-white/10 py-16 sm:py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="text-center">
            <span className="font-display text-xs font-bold uppercase tracking-wider text-[var(--ruum-teal)]">
              Protocolo Operativo
            </span>
            <h2 className="mt-2 font-display text-2xl font-black text-white sm:text-3xl">
              ¿Cómo funciona cada traslado?
            </h2>
            <p className="mx-auto mt-3 max-w-2xl font-body text-sm text-[#C7D5E7]">
              Cada traslado tiene folio, ruta y evidencia: tres pasos visibles de principio a fin.
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {IDENTIDAD_MARCA.pasosProtocolo.map((item) => (
              <div
                key={item.paso}
                className="relative rounded-xl border border-white/10 bg-white/5 p-5 transition hover:border-[var(--ruum-teal)]/50"
              >
                <div className="flex items-center justify-between">
                  <span className="flex size-8 items-center justify-center rounded-lg bg-[var(--ruum-teal-deep)] font-display text-sm font-black text-white">
                    {item.paso}
                  </span>
                  <span className="font-mono-ruum text-xs text-[#A9BCD3]">FASE {item.paso}</span>
                </div>
                <h3 className="mt-4 font-display text-base font-bold text-white">
                  {item.titulo}
                </h3>
                <p className="mt-2 font-body text-xs leading-relaxed text-[#B7C2D4]">
                  {item.descripcion}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. DIFERENCIADORES CLAVE (Páginas 4 & 28) */}
      <section className="border-b border-white/10 bg-[#121721] py-16 sm:py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="text-center">
            <span className="font-display text-xs font-bold uppercase tracking-wider text-[var(--ruum-teal)]">
              Ventajas Ruum Ruum
            </span>
            <h2 className="mt-2 font-display text-2xl font-black text-white sm:text-3xl">
              Diferenciadores Clave
            </h2>
          </div>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {IDENTIDAD_MARCA.diferenciadores.map((dif, idx) => (
              <div key={idx} className="rounded-xl border border-white/10 bg-white/5 p-5">
                <div className="flex size-10 items-center justify-center rounded-lg bg-[var(--ruum-teal)]/15 text-[var(--ruum-teal)]">
                  <Icono nombre="palomita" className="size-5" strokeWidth={2} />
                </div>
                <h3 className="mt-4 font-display text-base font-bold text-white">
                  {dif.titulo}
                </h3>
                <p className="mt-2 font-body text-xs leading-relaxed text-[#B7C2D4]">
                  {dif.descripcion}
                </p>
              </div>
            ))}
            <div className="rounded-xl border border-[var(--ruum-teal)]/30 bg-[var(--ruum-teal)]/10 p-5 flex flex-col justify-center">
              <h3 className="font-display text-base font-bold text-[var(--ruum-teal)]">
                Atención y Cotización
              </h3>
              <p className="mt-2 font-body text-xs text-[#F8F8F5]">
                Soporte por canales autorizados y WhatsApp Business con catálogo de servicios inmediato.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. MANIFIESTO Y CIERRE INSTITUCIONAL (Páginas 35 & 36) */}
      <section className="px-4 py-16 text-center sm:px-6 sm:py-24">
        <div className="mx-auto max-w-3xl">
          <SelloConductor tamano="md" tema="certificado" className="mx-auto mb-6" />
          <h2 className="font-display text-2xl font-black text-white sm:text-3xl">
            Sabes quién lleva tu auto y qué evidencia queda de cada etapa.
          </h2>
          <p className="mt-4 font-body text-sm leading-relaxed text-[#B7C2D4] sm:text-base">
            {IDENTIDAD_MARCA.manifiesto}
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link href="/registro" className={`sm:w-auto ${botonAzul} sm:px-8`}>
              Comenzar ahora
            </Link>
            <Link href="/login" className="inline-flex min-h-11 w-full sm:w-auto items-center justify-center rounded-lg px-5 py-3 font-display text-sm font-semibold text-[#8B98AD] transition hover:text-white">
              Iniciar sesión
            </Link>
          </div>
        </div>
      </section>

      {/* EVIDENCIA (cap. 28: el reporte es la prueba visible) */}
      <section className="border-t border-white/10 bg-white px-4 py-16 text-[var(--ruum-navy)] sm:px-6 sm:py-20">
        <div className="mx-auto max-w-5xl">
          <p className="text-center font-body text-xs font-bold uppercase tracking-wider text-[var(--ruum-teal-deep)]">
            Evidencia
          </p>
          <h2 className="mt-2 text-center font-body text-2xl font-bold sm:text-3xl">
            Cada traslado deja reporte, folio y firma
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-center font-body text-sm text-[var(--ruum-muted)]">
            Ejemplo ilustrativo con datos ficticios. El cliente recibe este paquete al cierre.
          </p>
          <dl className="mx-auto mt-8 grid max-w-3xl gap-4 rounded-[20px] border border-[var(--ruum-border)] bg-[var(--ruum-neutral-bg)] p-5 sm:grid-cols-2">
            <div><dt className="font-body text-xs font-semibold uppercase tracking-wider text-[var(--ruum-teal-deep)]">Folio</dt><dd className="font-body text-sm font-bold tabular-nums">RR-2026-0001</dd></div>
            <div><dt className="font-body text-xs font-semibold uppercase tracking-wider text-[var(--ruum-teal-deep)]">Ruta</dt><dd className="font-body text-sm">CDMX → Toluca</dd></div>
            <div><dt className="font-body text-xs font-semibold uppercase tracking-wider text-[var(--ruum-teal-deep)]">Conductor</dt><dd className="font-body text-sm">Conductor certificado · Nivel 2</dd></div>
            <div><dt className="font-body text-xs font-semibold uppercase tracking-wider text-[var(--ruum-teal-deep)]">Evidencia</dt><dd className="font-body text-sm">Fotos, odómetro, combustible y firma al recoger y entregar</dd></div>
          </dl>
        </div>
      </section>

      {/* FORMULARIO B2B (cap. 29: usted, formal, solo promesas verificables) */}
      <section id="empresas" className="border-t border-white/10 px-4 py-16 sm:px-6 sm:py-20">
        <div className="mx-auto max-w-3xl text-center">
          <p className="font-body text-xs font-bold uppercase tracking-wider text-[var(--ruum-teal)]">Empresas</p>
          <h2 className="mt-2 font-body text-2xl font-bold text-white sm:text-3xl">
            Cada unidad, documentada de origen a destino
          </h2>
          <p className="mx-auto mt-3 max-w-2xl font-body text-sm text-[#C7D5E7]">
            Solicite su propuesta. Le respondemos con alcance, duración y siguiente paso.
          </p>
          <FormularioPropuestaEmpresa />
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/10 bg-[#0d1117] px-4 py-8 sm:px-6">
        <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
          <div>
            <LogoMarca variante="horizontal" tema="oscuro" tamano={28} />
            <p className="mt-2 font-body text-xs text-[#8B98AD]">
              {IDENTIDAD_MARCA.lema}
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4 font-body text-xs text-[#8B98AD]">
            <Link href="#como-funciona" className="transition hover:text-white">
              Cómo funciona
            </Link>
            <Link href="/onboarding" className="transition hover:text-white">
              Recorrido guiado
            </Link>
            <Link href="/login" className="transition hover:text-white">
              Iniciar sesión
            </Link>
            <Link href="/registro" className="transition hover:text-white">
              Crear cuenta
            </Link>
            <Link href="/legal/terminos" className="transition hover:text-white">
              Términos y condiciones
            </Link>
            <Link href="/legal/privacidad" className="transition hover:text-white">
              Aviso de privacidad
            </Link>
            <Link href="/soporte" className="transition hover:text-white">
              Ayuda y soporte
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
